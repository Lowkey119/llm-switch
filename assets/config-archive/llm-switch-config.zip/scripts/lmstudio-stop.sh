#!/bin/zsh
# Mac-lmstudio 后端的停止脚本：停掉本机 LM Studio 的本地 API 服务（:1234）。
#
# 幂等要求见 services/script.rs：停止脚本以非 0 退出会被判成「停止失败」，
# 所以「本来就没在跑」也必须返回 0，否则重复点停止会看到一片红。
set -e

LMS="$HOME/.lmstudio/bin/lms"
if [ ! -x "$LMS" ]; then
  echo "找不到 lms CLI：$LMS（LM Studio 未安装，或版本换了路径）" >&2
  exit 127
fi

exec "$LMS" server stop
