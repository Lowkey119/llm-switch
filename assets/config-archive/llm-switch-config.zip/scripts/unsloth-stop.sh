#!/bin/zsh
# Unsloth 后端的停止脚本：关掉 Unsloth Studio（连同它拉起的 llama-server 推理子进程）。
#
# 幂等要求（services/script.rs）：本来就没在跑也必须 exit 0，重复点停止不许见红。
# 顺序先礼后兵：osascript 请 GUI 退出（Studio 会自己收尾推理子进程），
# 轮询等它走；超时不退才 pkill 升级——先 API 进程再 llama-server，防孤儿占内存。
set +e

APP_NAME="Unsloth"
LLAMA_BIN="$HOME/.unsloth/llama.cpp/build/bin/llama-server"

api_running() { pgrep -f "unsloth studio --api-only" >/dev/null 2>&1; }
gui_running() { pgrep -x unsloth-studio >/dev/null 2>&1; }
llama_running() { pgrep -f "$LLAMA_BIN" >/dev/null 2>&1; }

if ! gui_running && ! api_running && ! llama_running; then
  echo "Unsloth Studio 本来就没在跑"
  exit 0
fi

osascript -e "quit app \"$APP_NAME\"" 2>/dev/null
for _ in {1..20}; do
  gui_running || api_running || break
  sleep 0.5
done

# 先礼没动：强制收（API 进程在前，llama-server 在后）。
api_running && pkill -f "unsloth studio --api-only" 2>/dev/null
gui_running && pkill -x unsloth-studio 2>/dev/null
sleep 1
llama_running && pkill -f "$LLAMA_BIN" 2>/dev/null
sleep 1

if gui_running || api_running || llama_running; then
  echo "Unsloth Studio 没能停干净（gui=$(gui_running && echo y || echo n) api=$(api_running && echo y || echo n) llama=$(llama_running && echo y || echo n)），请手动检查" >&2
  exit 1
fi
echo "Unsloth Studio 已停止"
exit 0
