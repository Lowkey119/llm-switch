#!/bin/zsh
# mlx-serve 后端的启动脚本：拉起本机 mlx-serve 多模型服务（localhost:11234）。
#
# 前台 exec 形态：llm-switch 把本脚本的 stdout/stderr 直接落进
# logs/backend-scripts/<后端id>-start.log（控制台页可看），3 秒宽限内不退即算启动
# 成功——所以这里【不能】后台化，exec 后脚本进程就是服务本身。
#
# 模型目录与 omlx 共享（两边都只读 safetensors，无冲突）：--model-dir 可重复
# （≤8 个），DFlash 草稿目录会被引擎自动识别为 sidecar 跳过，不会混进模型列表。
#
# 路径写绝对值：GUI 应用 spawn 的子进程只有 launchd 极简 PATH（omlx-start.sh 同款坑）。
set -e

BIN="/opt/homebrew/bin/mlx-serve"
if [ ! -x "$BIN" ]; then
  echo "找不到 mlx-serve CLI：$BIN（brew install mlx-serve）" >&2
  exit 127
fi

# 幂等：11234 已有监听就视为已启动。脚本 3 秒内以 0 退出，llm-switch 判成
# 「已在运行」，不会重复拉起第二个实例抢端口。
if /usr/sbin/lsof -nP -iTCP:11234 -sTCP:LISTEN >/dev/null 2>&1; then
  echo "mlx-serve 已在 11234 监听，未重复启动"
  exit 0
fi

# v26.11.1 起针对无快速 bf16 数学的 Mac（M1/M2 正是）的 prefill 加速开关，
# 官方 CHANGELOG「Faster prompts on M1 and M2」；不适用时引擎自行回落，无损。
export MLX_SERVE_F16_PREFILL=1

exec "$BIN" serve \
  --model-dir /Users/lowkey/omlx_models \
  --model-dir /Users/lowkey/omlx_models/ornith-ai \
  --model-dir /Users/lowkey/omlx_models/mlx-community \
  --host 127.0.0.1 --port 11234 \
  --ctx-size 204800 \
  --idle-evict-secs 600 \
  --max-concurrent 2 \
  --metrics \
  --temp 0.6 --top-p 0.95 --top-k 20
