#!/bin/zsh
# Mac-lmstudio 后端的启动脚本：拉起本机 LM Studio 的本地 API 服务（192.168.31.100:1234）。
#
# 走 lms CLI 的托管启动，**不需要**先打开 LM Studio.app——实测 app 完全没运行时
# 它会自己报 "Waking up LM Studio service..." 并以 0 返回，所以不必先 open -a。
#
# 路径一律写绝对值：这个脚本由 GUI 应用 spawn，继承的是 launchd 那套极简 PATH
# （只有 /usr/bin:/bin:/usr/sbin:/sbin），$HOME/.lmstudio/bin 不在里面，
# 写命令名会直接 "command not found"。
set -e

LMS="$HOME/.lmstudio/bin/lms"
if [ ! -x "$LMS" ]; then
  echo "找不到 lms CLI：$LMS（LM Studio 未安装，或版本换了路径）" >&2
  exit 127
fi

exec "$LMS" server start
