#!/bin/zsh
# mlx-serve 后端的停止脚本：停掉本机 mlx-serve（:11234）。
#
# 幂等要求（services/script.rs）：「本来就没在跑」也得返回 0，否则重复点停止判失败。
# 匹配串带上 serve 与首个 model-dir，只打这一套实例，不误伤别的 mlx-serve 进程。
PATTERN="mlx-serve serve --model-dir /Users/lowkey/omlx_models"

if pgrep -f "$PATTERN" >/dev/null 2>&1; then
  pkill -f "$PATTERN"
  echo "mlx-serve 已停止"
else
  echo "mlx-serve 本来就没在跑"
fi
exit 0
