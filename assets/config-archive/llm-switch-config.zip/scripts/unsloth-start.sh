#!/bin/zsh
# Unsloth 后端的启动脚本：拉起 Unsloth Studio（API 在 127.0.0.1:8888）。
#
# 幂等（services/script.rs 契约）：:8888 已在监听就立刻 exit 0——3 秒内退出
# 且码为 0 会被判成「已在运行」，这正是重复点启动时想要的回执。
# 没在跑就 open -a 拉 GUI，然后轮询端口等 API 真就绪：Studio 是 GUI 应用，
# open 秒回、服务不归脚本托管（不能像 mlx-serve-start.sh 那样 exec 常驻），
# 所以用「轮询到就绪才退」的形态——3 秒宽限内没退即算启动成功，
# 轮询失败（120s 没起来）时脚本以非 0 退出，控制台页的健康检查会如实报红。
#
# 路径写绝对值：GUI 应用 spawn 的子进程只有 launchd 极简 PATH（其它脚本同款坑）。
set -e

PORT=8888
APP="/Applications/Unsloth.app"

listening() { lsof -nP -iTCP:$PORT -sTCP:LISTEN >/dev/null 2>&1; }

if listening; then
  echo "Unsloth Studio 已在 :$PORT 监听"
  exit 0
fi

[ -d "$APP" ] || { echo "找不到 $APP（Unsloth 未安装，或装到别处了）" >&2; exit 127; }
open -a "Unsloth"

# Studio 冷启动（venv python 起 API server）实测十几到几十秒，给 120s 预算。
for _ in {1..240}; do
  listening && { echo "Unsloth Studio 已就绪（:$PORT）"; exit 0; }
  sleep 0.5
done
echo "等了 120 秒 :$PORT 仍未监听——请看 Unsloth 窗口是否有报错" >&2
exit 1
