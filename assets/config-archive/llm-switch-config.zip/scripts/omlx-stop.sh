#!/bin/zsh
# omlx 后端的停止脚本：停掉本机 oMLX 服务（:8000）。
#
# 与启动成对，同样走 omlx 自己的托管命令；幂等要求见 services/script.rs——
# 「本来就没在跑」也得返回 0，否则重复点停止会被判成失败。
set -e

OMLX="/opt/homebrew/bin/omlx"
if [ ! -x "$OMLX" ]; then
  echo "找不到 omlx CLI：$OMLX（oMLX 没装，或装在别处）" >&2
  exit 127
fi

exec "$OMLX" stop
