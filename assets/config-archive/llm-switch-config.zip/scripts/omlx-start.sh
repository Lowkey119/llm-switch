#!/bin/zsh
# omlx 后端的启动脚本：拉起本机 oMLX 服务（localhost:8000）。
#
# 用 omlx 自带的托管生命周期命令（README「Quickstart · CLI」一节就是为后台服务
# 准备的），它自己负责 daemon 的起落与落日志，不要改成 `omlx serve`——那个是
# 绑前台、跟着本进程走的形态，脚本一退出服务就没了，还会被 3 秒宽限判成「没起来」。
#
# 路径写绝对值：GUI 应用 spawn 出来的子进程只有 launchd 那套极简 PATH，
# /opt/homebrew/bin 不在里面，写命令名会直接 "command not found"。
set -e

OMLX="/opt/homebrew/bin/omlx"
if [ ! -x "$OMLX" ]; then
  echo "找不到 omlx CLI：$OMLX（oMLX 没装，或装在别处）" >&2
  exit 127
fi

exec "$OMLX" start
