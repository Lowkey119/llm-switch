# 本机 EditHere 安装记录

本机配置时生成。skill 优先读取本文件记录的 CLI 绝对路径。

- **CLI 绝对路径**：`/Applications/EditHere.app/Contents/MacOS/edithere-cli`
- 程序版本：`0.12.5`（分支 `codex/native`，本机自编译，Qt 6.9.3 / arm64 / ad-hoc 签名）
- 源码与构建笔记：`~/myllm/edithere`（见 `BUILD-LOCAL-macos.md`）
- 配套 MCP 连接器（可选，未启用）：`~/myllm/edithere/connector/mcp-server.mjs`

## 每次任务前的最小验证

```bash
EditHereCli=/Applications/EditHere.app/Contents/MacOS/edithere-cli
"$EditHereCli" --version   # EditHere 0.12.5，不连接桌面
"$EditHereCli" status      # {"running":true,...,"version":"0.12.5","ok":true}
```

`status` 里 `running:false` 表示桌面程序没在跑，用 `open /Applications/EditHere.app` 启动后再试。

## 首次使用需要的系统权限

| 权限 | 用途 | 表现 |
| --- | --- | --- |
| 屏幕录制 | `capture` / 全局快捷键 `Option+Shift+2` | 未授权时截出来是空白 |
| 辅助功能 | 智能选块读系统元素边界 | 未授权时纯图片批注仍可用，托盘菜单有「授予辅助功能权限」入口 |

## 其它

- 全局快捷键：截图 `Option+Shift+2`，新建批注窗口 `Option+Shift+1`。
- 反馈 JSON 默认落在系统临时目录下的 `edithere-feedback/`，`annotate --output` 可指定。
- 本机构建与官方包的差异：仅 arm64、未 Apple 公证。
