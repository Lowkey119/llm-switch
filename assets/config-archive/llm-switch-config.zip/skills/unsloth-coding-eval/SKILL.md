---
name: unsloth-coding-eval
description: 对 Unsloth Studio 引擎中已部署的模型做编码能力评测（多轮、200k 上下文门槛、幻觉门槛、MTP/DFlash 投机全开、量化精度参考），产出按能力与速率排序的排行榜。触发词——测试/评测 unsloth 模型、模型编码能力测试、200k 上下文测试、unsloth 模型排行、跑模型评测、coding model eval。
---

# Unsloth 编码模型评测（unsloth-coding-eval）

完整方法论见仓内计划：`~/myllm/llm-switch/docs/plan/2026-11-07-unsloth编码模型评测计划.md`。
本技能是它的可执行形态。

## When to Use

- 用户要评测/复测 Unsloth Studio 里已部署模型的编码能力，或要更新排行榜。
- 引擎新装了模型、换了量化、或 Studio 升级了投机解码后需要回归。

不适用：非 Unsloth 引擎（omlx/halogen 等）；需要下载新模型的评测（本技能**只测已部署**）。

## Prerequisites

1. Unsloth Studio 在跑：`http://127.0.0.1:8888`（`GET /v1/models` 可通）。
2. 密钥（**绝不写死进任何文件**）：环境变量 `UNSLOTH_API_KEY`，否则 harness 自动从
   `~/.llm-switch/llm-switch.db` 的 `backends` 表（`engine='unsloth'`）读取。
3. 本机 `python3`（判分用）与 `node`（TypeScript/JS 题判分用）。
4. 磁盘：结果落 `~/myllm/llm-switch/eval-results/<日期>/`（已 gitignore）。

## Procedure

### 0. 扫描 → 用户选序号（技能入口，必做）

```bash
python3 ~/.llm-switch/skills/unsloth-coding-eval/scripts/unsloth_eval.py models
```

1. 该命令调用 `GET /v1/models` 扫描引擎已部署模型，剔除 `Embedding`/`FLUX` 等非编码 LLM，
   以**数字序号**列表呈现（id、量化、形态、已加载、原生 ctx）。
2. 把这份编号列表**原样发给用户**，请用户回复**本次要测的模型序号（逗号分隔，如 `1,3,5`）**。
   未得到用户选择前不得开跑。
   ⚠️ `/v1/models` 顺序是动态的（加载/变体会改变列表）：`models` 子命令会把序号快照写
   `eval-results/<日期>/scan.json`，`run --pick` 以快照为准；若扫描与选择之间重跑过
   `models`，必须重新给用户列表确认，或用 `--model <id>` 显式指定。
3. 用户选定后按序号逐一测试：

```bash
python3 .../unsloth_eval.py run --pick 1,3,5 --suite full   # 快筛用 --suite quick
python3 .../unsloth_eval.py leaderboard                     # 全部测完汇总排行
```

### 1. 枚举与过滤规则（脚本内置）

- 枚举：`GET /v1/models`（Bearer 鉴权，见 Prerequisites）。
- **排除**（非编码 LLM）：id 含 `Embedding`、`FLUX`（图像）、以及任何 `object != model` 的条目。
- 保留全部文本生成模型进入候选；小模型不预先剔除——让门槛自然淘汰，榜单可复核。

### 2. 逐模型评测（核心循环，按用户所选序号顺序）

```bash
# 快筛（G0+CTX1+H1+C1抽3题，先淘汰）
python3 .../unsloth_eval.py run --model <id> --suite quick
# 全量
python3 .../unsloth_eval.py run --model <id> --suite full
# 全部模型 + 断点续跑
python3 .../unsloth_eval.py run --all --suite full --resume
```

每个模型内部按固定顺序执行（脚本已实现骨架，缺的部分由代理按下述规则补齐并回写脚本）：

1. **驻留核对**：`GET /api/inference/loaded-models`，有残留先 `POST /v1/unload`。
2. **加载**（`POST /v1/load`，轮询 `GET /v1/load-progress` 至 `phase=ready`）：
   ```json
   {"model_path":"<id>","max_seq_length":204800,"speculative_type":"auto",
    "spec_draft_n_max":3,"force_reload":true}
   ```
   降级链：200k 加载失败 → KV 量化重试（GGUF `cache_type_kv:"q8_0"` / MLX `mlx_kv_quant:"8"`，
   再降 `"4"`/`"q4_0"`）→ 仍失败则 `max_seq_length:0` 原生窗口（CTX 门槛判负但照跑能力项）。
   投机降级：`auto` → `mtp`（id 含 mtp 时）→ `off`；**实际生效档位必须实测记录**（看加载日志），
   不许把 `auto` 当成已生效。
3. **统一采样参数**（每次 chat 请求逐字相同）：
   ```json
   {"temperature":0.0,"top_p":1.0,"repetition_penalty":1.0,"seed":42,
    "max_tokens":8192,"stream":true,"stream_options":{"include_usage":true}}
   ```
   `repetition_penalty` 必须显式传 1.0——Studio 给 Heretic 设了模型级 1.05，不覆盖会破坏统一性。
   系统提示统一：`You are a coding assistant. Answer precisely. Output code in fenced blocks.`
4. **测试组**（题库 `question_bank.json`，每题 3 轮独立重复；pass=3/3，flaky=部分）：
   - G0 可加载+响应；SP 速率探针（8k prompt/512 生成，流式计时 TTFT、prefill、decode tok/s）
   - C1 代码生成×10、C2 修bug×5（提取代码块→落盘→跑内嵌测试，python 用 `python3`、ts 用 `node`）
   - C3 多轮对话×2（4 回合，末版过测试）；C4 指令遵循×5（JSON schema / SEARCH-REPLACE 格式校验）
   - H1 幻觉陷阱×10（不存在的 API/库必须识破；事实题核对关键词）；H2 跨轮一致性×5
   - CTX1 **200k 大海捞针**：真实代码语料拼至 `usage.prompt_tokens ≥ 190k`，5 根针埋深
     10/30/50/70/90%，5/5 全中才过；同时记录长上下文 decode tok/s
   - CTX2 长文埋 bug 定位修复×1
5. **完赛判定**：任一题任一轮空响应/拒答/截断缺尾 → 该模型 DNF，记录原因，不入榜。
6. 卸载模型，写单模型结果 JSON，下一个。

### 3. 测试报告（每模型一份，必含测试参数）

每测完一个模型落 `report_<模型>.md/.json`（`eval-results/<日期>/`），报告**必须原样列出测试时
实际使用的模型参数**：

- **加载参数**：`POST /v1/load` 实际发送的完整 JSON（含降级链最终命中的 KV 档位）；
- **采样参数**：每次 chat 请求的完整 JSON（temperature/top_p/repetition_penalty/seed/max_tokens/stream）；
- **系统提示**原文；
- 实测环境项：量化精度、形态、实际 ctx、投机解码实际生效档位、KV 模式；
- 门槛结果、能力分明细、速率、逐题逐轮 verdict。

### 4. 汇总排行

```bash
python3 .../unsloth_eval.py leaderboard
```

- 硬门槛（全过才入榜）：G0 ∧ CTX1 ∧ H1≥9/10 ∧ 完赛率100%。
- 能力分 100：C1 25 + C2 15 + C3 20 + C4 10 + H1 15 + H2 10 + CTX2 5（flaky 按半分）。
- 速率分：短/长上下文 decode tok/s 几何平均，归一化到全体最大。
- **排序：能力分降序，±2 分内比速率**；综合分 `0.7×能力+0.3×速率` 供参考。
- 排行榜必含列：量化精度、形态(MLX/GGUF)、实际 ctx、投机档位、TTFT、门槛明细。

## Pitfalls

- **长轮次 usage 可能缺失**（llama.cpp 路径实测）：超长多轮请求服务端正常完成，
  但客户端收到空 content/无 usage。判分以生成内容为准；终轮生成 token 数看
  llama-server 日志 `eval time = ... / N tokens` 区分「模型没答」vs「链路断流」。
- **长上下文捞针是真实能力门槛**：同机同参下 MLX 件 228k 全中、GGUF 件 156k 全失
  （终轮仅生成 8 token = 模型直说找不到）——不要拿链路问题当遮羞布，看服务端生成量定性。
- **已部署 ≠ 缓存完整**：`/v1/models` 列出的 HF 仓模型可能缺文件（看
  `/api/models/download-progress?repo_id=` 的 `complete_on_disk`/`expected_bytes`），
  HF 不可达时 `/v1/load` 会挂在下发校验上死循环重试。harness 已内置**加载前预检**，
  缺件模型直接 SKIP 并落 `skipped_*.json`（不算 DNF，是环境前置）；本地目录模型（如
  `~/omlx_models/` 扫描进来的）不经 HF，直接放行。
- **DFlash/DSpark 伴生 drafter 可能已在本地**（如 `*-DFlash` 目录）：`speculative_type=auto`
  会优先用缓存伴生；MLX 可显式 `spec_draft_model=<本地 drafter 路径>`。实测档位写进报告。
- **64GB 内存红线**：35B Q4 + 200k fp16 KV ≈ 40GB+，KV 降级链不是可选项是必选项；
  加载失败先查残留驻留再看 Studio 日志（`~/.unsloth/studio/logs/backend-*.log`）。
- **一次只驻留一个模型**：`alongside` 恒 false；每步核对 `loaded-models`，防引擎自动换载串台。
- **投机解码无损只在贪心/temp=0 成立**——采样参数里 temperature 不许动。
- **seed 在 MLX 侧可能无效**：跨轮波动记 flaky，别当故障排查。
- **200k prefill 很慢**（M1 Max 约 10–30 分钟/次）：harness HTTP 读超时 ≥30 分钟；
  全量 12 模型约 6–12 小时，建议先 `--suite quick` 快筛再全量，或夜间分批。
- **密钥零落盘**：结果/日志/排行榜出现 `sk-unsloth-` 前缀即为泄密，立即清理。
- **不下载模型**：`/v1/load` 对未缓存模型会触发下载——被测清单只从 `/v1/models` 已部署列表取。
- **H1 判分是关键词 rubric**：自动判分后必须人工抽检每模型至少 2 题，防误杀/漏放。

## Verification

1. `models` 子命令输出的模型集合 == `GET /v1/models` 去掉 Embedding/FLUX 的集合；
   且开跑前拿到过用户回复的序号清单。
2. 单模型结果 JSON 里：`spec_resolved`、`kv_mode`、`actual_ctx` 三字段非空（实测值，非声明值）。
3. 每份报告都含「加载参数 + 采样参数 + 系统提示」三节，且与实际发送一致。
4. CTX1 记录里有 `prompt_tokens ≥ 190000` 的 usage 证据。
5. `leaderboard.md` 排序符合 §6.4（能力降序、同分比速率），且每个未入榜模型有原因。
6. `grep -r "sk-unsloth" eval-results/` 无命中。
