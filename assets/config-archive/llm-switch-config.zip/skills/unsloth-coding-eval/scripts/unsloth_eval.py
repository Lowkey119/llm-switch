#!/usr/bin/env python3
"""Unsloth Studio 编码模型评测 harness（仅标准库）。

流程：models 扫描编号 → 用户选序号 → run --pick 逐一测试 → 报告(含测试参数) → leaderboard。
密钥：环境变量 UNSLOTH_API_KEY，否则从 ~/.llm-switch/llm-switch.db 读取，绝不落盘。
计划文档：~/myllm/llm-switch/docs/plan/2026-11-07-unsloth编码模型评测计划.md
"""
import argparse
import json
import os
import re
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

BASE = os.environ.get("UNSLOTH_BASE", "http://127.0.0.1:8888")
REPO = Path.home() / "myllm/llm-switch"
EXCLUDE = ("embedding", "flux")  # 非编码 LLM
CTX_TARGET = 204800              # ≥200k 硬需求
NEEDLE_MIN_TOKENS = 190000

# ---- 统一参数（报告必须原样列出这些） ---------------------------------------
LOAD_BASE = {"speculative_type": "auto", "spec_draft_n_max": 3, "force_reload": True,
             "n_parallel": 1}  # 单槽才能把 200k 全给一个 slot（多槽会被 fitter 切小）
KV_FALLBACKS = [  # 200k 内存适配链（64GB M1 Max）
    {},                                        # 默认 fp16 KV
    {"cache_type_kv": "q8_0"},                 # GGUF
    {"mlx_kv_quant": "8"},                     # MLX
    {"mlx_kv_quant": "4", "cache_type_kv": "q4_0"},
]
SAMPLING = {  # 每次 chat 请求逐字相同（编码评测：贪心 + 固定 seed，投机解码因此无损）
    "temperature": 0.0, "top_p": 1.0, "repetition_penalty": 1.0, "seed": 42,
    "max_tokens": 8192, "stream": True, "stream_options": {"include_usage": True},
}
SYSTEM = "You are a coding assistant. Answer precisely. Output code in fenced blocks."
SPEC_FALLBACKS = ["auto", "mtp", "off"]  # id 不含 mtp 时跳过 mtp


def log(*a):
    print(f"[{time.strftime('%H:%M:%S')}]", *a, flush=True)


def get_key():
    k = os.environ.get("UNSLOTH_API_KEY")
    if k:
        return k.strip()
    db = Path.home() / ".llm-switch/llm-switch.db"
    if db.exists():
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        try:
            row = con.execute(
                "select api_key from backends where engine='unsloth' "
                "and api_key is not null limit 1").fetchone()
            if row and row[0]:
                return row[0].strip()
        finally:
            con.close()
    sys.exit("缺密钥：设 UNSLOTH_API_KEY 或确保 llm-switch.db 里有 unsloth 后端密钥")


KEY = None


def api(path, method="GET", body=None, timeout=120):
    global KEY
    if KEY is None:
        KEY = get_key()
    req = urllib.request.Request(
        BASE + path, method=method,
        data=json.dumps(body).encode() if body is not None else None,
        headers={"Authorization": f"Bearer {KEY}",
                 "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        detail = e.read().decode()[:400]
        raise RuntimeError(f"{method} {path} -> {e.code}: {detail}") from None


# ---- 模型枚举（扫描步骤） ----------------------------------------------------

def scan_models():
    data = api("/v1/models")["data"]
    out = []
    for m in data:
        mid = m["id"]
        if any(x in mid.lower() for x in EXCLUDE) or m.get("object") != "model":
            continue
        quant = m.get("quant") or guess_quant(mid)
        if "gguf" in mid.lower():
            form = "GGUF"
        elif "mlx" in mid.lower() or quant.lower().startswith("oq"):
            form = "MLX"  # oQ* 量化是 MLX 专属命名
        else:
            form = "?"
        out.append({"id": mid, "quant": quant, "form": form,
                    "loaded": bool(m.get("loaded")),
                    "ctx": m.get("context_length")})
    return out


def guess_quant(mid):
    m = re.search(r"(oQ\d+e?(?:-fp16)?|UD-Q[\w_]+|APEX-[\w-]+|Q\d+_[\w]+|\d+bit)", mid, re.I)
    return m.group(1) if m else "-"


def cmd_models(_args):
    models = scan_models()
    print("已部署的编码候选模型（用户按序号选择，逗号分隔）：\n")
    for i, m in enumerate(models, 1):
        print(f"  {i:>2}. {m['id']}\n      量化={m['quant']} 形态={m['form']} "
              f"已加载={m['loaded']} 原生ctx={m['ctx']}")
    # 快照钉死序号：/v1/models 顺序会变，run --pick 以这份为准
    snap = Path(REPO / "eval-results" / time.strftime("%Y%m%d") / "scan.json")
    snap.parent.mkdir(parents=True, exist_ok=True)
    snap.write_text(json.dumps(models, ensure_ascii=False, indent=1))
    log("序号快照已写:", snap)
    return models


def pick_models(pick):
    snap = Path(REPO / "eval-results" / time.strftime("%Y%m%d") / "scan.json")
    models = (json.loads(snap.read_text()) if snap.exists() else scan_models())
    return [models[int(i.strip()) - 1]["id"] for i in pick.split(",")]


# ---- 加载 / 卸载 --------------------------------------------------------------

def loaded_models():
    try:
        r = api("/api/inference/loaded-models")
        items = r if isinstance(r, list) else r.get("data") or r.get("models", [])
        return [x.get("model_path") or x.get("id") or x for x in items if x]
    except Exception:
        return []


def unload_all():
    for m in loaded_models():
        log("unload", m)
        try:
            api("/v1/unload", "POST", {"model_path": m})
        except Exception as e:
            log("  unload 失败(忽略):", e)
    time.sleep(2)


def registered_id(mid):
    """本地路径加载后注册 id 可能与请求 id 不同（如去前缀）；chat 必须用实际注册 id。"""
    for m in loaded_models():
        if _id_match(mid, m):
            return str(m)
    return mid


def _id_match(a, b):
    a, b = str(a), str(b)
    return a == b or a in b or b in a or a.split("/")[-1] == b.split("/")[-1]


def wait_ready(mid=None, timeout=1200):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            p = api("/v1/load-progress")
            loaded = loaded_models()
            if p.get("phase") == "ready":
                return True
            if mid and any(_id_match(mid, m) for m in loaded):
                return True
            if p.get("phase") is None and loaded and not mid:
                return True
        except Exception:
            pass
        time.sleep(5)
    return False


def cache_check(mid):
    """加载前预检：HF 仓缺文件且网络不通时 /v1/load 会挂在下发校验上。
    返回 (ok, reason)。本地目录模型（omlx_models 等）不经 HF，直接放行。"""
    try:
        d = api(f"/api/models/download-progress?repo_id={mid}", timeout=15)
    except Exception:
        return True, ""
    if d.get("complete_on_disk"):
        return True, ""
    exp = d.get("expected_bytes") or 0
    if exp and exp > 0:
        return False, f"缓存不完整：缺 {exp} 字节（HF 不可达时加载会挂死）"
    return True, ""  # expected=0：多为元数据校验，本地件可试


def local_path_for(mid):
    """id 解析失败（如 ModelScope 源查无）时回退本地模型目录。"""
    for root in (Path.home() / "omlx_models",):
        p = root / mid
        if p.is_dir():
            return str(p)
    return None


def load_model(mid):
    """按降级链加载；返回 (实际发送的加载参数, kv_mode, spec_resolved, actual_ctx)。"""
    spec_chain = SPEC_FALLBACKS if "mtp" in mid.lower() else ["auto", "off"]
    extra = {"disable_vision": True} if mid.lower().endswith("gguf") else {}
    lp = local_path_for(mid)
    for spec in spec_chain:
        for i, kv in enumerate(KV_FALLBACKS):
            # 本地目录件优先用路径：Studio 的 id→本地解析不稳定（会误走 HF/ModelScope）
            body = {"model_path": lp or mid, "max_seq_length": CTX_TARGET,
                    **LOAD_BASE, "speculative_type": spec, **kv, **extra}
            try:
                log(f"load {mid} spec={spec} kv#{i}")
                api("/v1/load", "POST", body, timeout=1200)
                if wait_ready(mid):
                    kv_mode = ("fp16" if not kv else
                               kv.get("cache_type_kv") or f"mlx_kv{kv.get('mlx_kv_quant')}")
                    return body, kv_mode, f"requested:{spec}", CTX_TARGET
            except Exception as e:
                msg = str(e)[:200]
                log("  加载失败:", msg)
                # id 解析失败（源设置）→ 用本地路径重试一次
                if lp and ("ModelScope" in msg or "not found" in msg.lower()):
                    body2 = dict(body, model_path=lp)
                    try:
                        log(f"  本地路径回退: {lp}")
                        api("/v1/load", "POST", body2, timeout=1200)
                        if wait_ready(mid):
                            kv_mode = ("fp16" if not kv else
                                       kv.get("cache_type_kv") or f"mlx_kv{kv.get('mlx_kv_quant')}")
                            return body2, kv_mode, f"requested:{spec}", CTX_TARGET
                    except Exception as e2:
                        log("  本地回退也失败:", str(e2)[:150])
                unload_all()
        # 该 spec 下所有 KV 都失败 → 试下一个 spec
    # 全链失败：原生窗口兜底（CTX 门槛判负）
    body = {"model_path": lp or mid, "max_seq_length": 0, **LOAD_BASE,
            "speculative_type": "off"}
    try:
        api("/v1/load", "POST", body, timeout=1200)
    except Exception as e:
        raise RuntimeError(f"加载彻底失败: {e}") from None
    ok = wait_ready(mid)
    return body, "native", "off", ("native" if ok else 0)


# ---- 对话（流式 + 计时） ------------------------------------------------------

def chat(mid, messages, max_tokens=None, timeout=2400):
    global KEY
    body = {"model": mid, "messages": messages, **SAMPLING}
    if max_tokens:
        body["max_tokens"] = max_tokens
    req = urllib.request.Request(
        BASE + "/v1/chat/completions", data=json.dumps(body).encode(),
        headers={"Authorization": f"Bearer {KEY}",
                 "Content-Type": "application/json"})
    t0 = time.time()
    t_first = None
    text = []
    reasoning = []
    stream_errors = []
    usage = {}
    with urllib.request.urlopen(req, timeout=timeout) as r:
        for raw in r:
            line = raw.decode().strip()
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if payload == "[DONE]":
                break
            try:
                c = json.loads(payload)
            except json.JSONDecodeError:
                continue
            if c.get("error"):
                stream_errors.append(str(c["error"])[:300])
                continue
            if c.get("usage"):
                usage = c["usage"]
            for ch in c.get("choices", []):
                delta = ch.get("delta") or {}
                d = delta.get("content")
                rc = delta.get("reasoning_content") or delta.get("reasoning")
                if d or rc:
                    if t_first is None:
                        t_first = time.time()
                    (text.append(d) if d else reasoning.append(rc))
    t_end = time.time()
    out = "".join(text)
    if not out.strip() and reasoning:
        out = "".join(reasoning)  # 推理模型可能全走 reasoning 通道
    pt = usage.get("prompt_tokens") or 0
    ct = usage.get("completion_tokens") or max(1, len(out) // 4)
    ttft = (t_first - t0) if t_first else None
    dec = ct / (t_end - t_first) if t_first and t_end > t_first else None
    pre = pt / (t_first - t0) if t_first and t_first > t0 and pt else None
    return {"text": out, "prompt_tokens": pt, "completion_tokens": ct,
            "ttft_s": round(ttft, 2) if ttft else None,
            "decode_tps": round(dec, 1) if dec else None,
            "prefill_tps": round(pre, 1) if pre else None,
            "truncated": bool(usage.get("completion_tokens", 0) >=
                              (max_tokens or SAMPLING["max_tokens"])),
            "stream_errors": stream_errors}


def valid(resp):
    """完赛判定：非空、未拒答、未截断缺尾。"""
    t = (resp.get("text") or "").strip()
    if not t or resp.get("truncated"):
        return False
    low = t.lower()
    return not low.startswith(("i can't", "i cannot", "i'm sorry", "抱歉，我无法", "我无法"))


# ---- 判分 ---------------------------------------------------------------------

def extract_code(text, lang):
    blocks = re.findall(r"```(\w*)\n(.*?)```", text, re.S)
    if not blocks:
        return None
    want = {"python": ("python", "py", ""), "node": ("javascript", "js",
                                                    "typescript", "ts")}[lang]
    cand = [b for l, b in blocks if l.lower() in want] or [b for _, b in blocks]
    return max(cand, key=len)


def grade_python(code, test_src):
    with tempfile.TemporaryDirectory() as d:
        Path(d, "solution.py").write_text(code)
        Path(d, "test_main.py").write_text(test_src)
        r = subprocess.run([sys.executable, "test_main.py"], cwd=d,
                           capture_output=True, text=True, timeout=60)
        return r.returncode == 0, r.stdout[-500:] + r.stderr[-500:]


def grade_node(code, test_src):
    with tempfile.TemporaryDirectory() as d:
        Path(d, "solution.mjs").write_text(code)
        Path(d, "test.mjs").write_text(test_src)
        r = subprocess.run(["node", "test.mjs"], cwd=d,
                           capture_output=True, text=True, timeout=60)
        return r.returncode == 0, r.stdout[-500:] + r.stderr[-500:]


def norm(s):
    """判分前归一化：去 markdown 强调/反引号，避免 `does **not** have` 误判。"""
    return s.replace("*", "").replace("`", "")


def grade_h1(q, text):
    low = norm(text).lower()
    if q["kind"] == "trap":
        return any(k.lower() in low for k in q["must_contain_any"])
    return all(k.lower() in low for k in q.get("must_contain_all", []))


def grade_c4(q, text):
    if q["kind"] == "json":
        m = re.search(r"\{.*\}", text, re.S)
        if not m:
            return False
        try:
            obj = json.loads(m.group(0))
        except json.JSONDecodeError:
            return False
        return all(k in obj for k in q.get("required_keys", []))
    if q["kind"] == "searchreplace":
        return all(k in text for k in ("<<<<<<< SEARCH", "=======", ">>>>>>> REPLACE"))
    return False


# ---- CTX1 大海捞针 -------------------------------------------------------------

def build_haystack(n_chars):
    """拼接确定性代码语料到指定字符量（token 数由调用方用 usage 实测反推）。"""
    files = sorted(p for p in REPO.rglob("*")
                   if p.suffix in {".rs", ".ts", ".tsx", ".py", ".js"}
                   and "node_modules" not in p.parts and "target" not in p.parts
                   and p.stat().st_size < 200_000)
    chunks, total = [], 0
    for f in files:
        try:
            t = f.read_text(errors="ignore")
        except Exception:
            continue
        chunks.append(f"\n// ==== file: {f.relative_to(REPO)} ====\n{t}")
        total += len(t)
        if total >= n_chars:
            break
    return "".join(chunks)


def ctx1(mid):
    """200k 大海捞针（多轮增量喂入）：Studio 代理会砍 >~170s 无数据的流，
    故把长提示切成 ~40k token/块逐轮喂（每块 prefill 在窗口内，KV 在 slot 累积），
    末轮提问；用末轮 usage.prompt_tokens 实测验收 ≥190k。"""
    cpt = 4.4  # chars/token 初估，按实测修正
    last_pt = 0
    for _ in range(3):
        needles = [(d, os.urandom(3).hex().upper(), f"mod_{os.urandom(2).hex()}")
                   for d in (0.10, 0.30, 0.50, 0.70, 0.90)]
        text = build_haystack(int(198000 * cpt))
        for i, (depth, code, mod) in enumerate(needles, 1):
            pos = int(len(text) * depth)
            pos = text.find("\n", pos) + 1
            text = text[:pos] + f"\n// NEEDLE-{i}: {code} belongs to module {mod}\n" + text[pos:]
        msgs = [{"role": "system", "content": SYSTEM}]
        # 分块嗂入：每块 ~150k 字符（≈ 35k token，prefill 约 100s，在代理窗口内）
        step = 150_000
        try:
            for start in range(0, len(text), step):
                msgs.append({"role": "user",
                             "content": text[start:start + step]
                             + "\n\n[context part, just reply 'k']"})
                r = chat(mid, msgs, max_tokens=8, timeout=600)
                msgs.append({"role": "assistant", "content": r["text"] or "k"})
            msgs.append({"role": "user",
                         "content": "Find every line starting with '// NEEDLE-' in the "
                                    "codebase above. List each needle's hex code and its "
                                    "module name, one per line."})
            r = chat(mid, msgs, max_tokens=2048, timeout=1200)
        except Exception as e:
            msg = str(e)[:300]
            low = msg.lower()
            if "exceed" in low or "too long" in low:
                cpt *= 0.85  # 终轮超长 → 缩字符量重试
                continue
            return {"pass": False, "error": msg, "needles_hit": "0/5",
                    "prompt_tokens": last_pt}
        pt = r["prompt_tokens"] or last_pt
        last_pt = pt
        if pt and pt < NEEDLE_MIN_TOKENS:
            cpt = min(8.0, cpt * (200000.0 / pt))
            continue
        hits = sum(1 for _, code, _ in needles if code in r["text"])
        return {"pass": hits == 5 and pt >= NEEDLE_MIN_TOKENS,
                "needles_hit": f"{hits}/5", "prompt_tokens": pt,
                "final_raw": (r.get("text") or "")[:600],
                "stream_errors": r.get("stream_errors", []),
                "decode_tps_long": r["decode_tps"], "ttft_long_s": r["ttft_s"]}
    return {"pass": False, "error": "自适应未达标",
            "needles_hit": "0/5", "prompt_tokens": last_pt}


# ---- 速率探针 -------------------------------------------------------------------

def speed_probe(mid):
    corpus = build_haystack(32000)[:32000]
    q = (f"Probe-{os.urandom(4).hex()} Read this context, then write a Python function "
         "parse_iso8601(s) supporting timezone offsets and Z, with docstring and asserts. "
         "Context:\n" + corpus[:30000])
    r = chat(mid, [{"role": "system", "content": SYSTEM},
                   {"role": "user", "content": q}], max_tokens=512)
    return {"ttft_s": r["ttft_s"], "prefill_tps": r["prefill_tps"],
            "decode_tps": r["decode_tps"], "prompt_tokens": r["prompt_tokens"]}


# ---- 题库执行 ---------------------------------------------------------------------

def run_bank(mid, bank, rounds, suite):
    res = {}
    groups = ({"C1", "H1", "SP", "CTX1", "G0"} if suite == "quick" else
              {"C1", "C2", "C3", "C4", "H1", "H2"}) if suite not in ("ctx1", "h1") \
        else ({"CTX1"} if suite == "ctx1" else {"H1"})

    for grp in ("C1", "C2"):
        if grp not in groups:
            continue
        scores = []
        for q in bank.get(grp, []):
            per = []
            for _ in range(rounds):
                msgs = [{"role": "system", "content": SYSTEM}]
                if grp == "C2":
                    msgs.append({"role": "user",
                                 "content": f"Fix this code so the tests pass:\n```\n{q['code']}\n```\n{q['prompt']}"})
                else:
                    msgs.append({"role": "user", "content": q["prompt"]})
                r = chat(mid, msgs)
                ok = valid(r)
                code = extract_code(r["text"], q["lang"]) if ok else None
                if code:
                    ok, _ = (grade_python if q["lang"] == "python"
                             else grade_node)(code, q["test"])
                per.append(ok)
            scores.append({"id": q["id"], "rounds": per,
                           "raw_tail": (r.get("text") or "")[:400],
                           "verdict": "pass" if all(per) else ("flaky" if any(per) else "fail")})
        res[grp] = scores

    if "C3" in groups and bank.get("C3"):
        sess = []
        for s in bank["C3"]:
            msgs = [{"role": "system", "content": SYSTEM}]
            turn_ok = []
            for turn in s["turns"]:
                msgs.append({"role": "user", "content": turn})
                r = chat(mid, msgs)
                turn_ok.append(valid(r))
                msgs.append({"role": "assistant", "content": r["text"]})
            code = extract_code(msgs[-1]["content"], s["lang"])
            final = bool(code) and (grade_python if s["lang"] == "python"
                                    else grade_node)(code, s["test"])[0]
            sess.append({"id": s["id"], "final_pass": final,
                         "turns_valid": f"{sum(turn_ok)}/{len(turn_ok)}"})
        res["C3"] = sess

    if "C4" in groups:
        sc = []
        for q in bank.get("C4", []):
            per = []
            for _ in range(rounds):
                r = chat(mid, [{"role": "system", "content": SYSTEM},
                               {"role": "user", "content": q["prompt"]}])
                per.append(valid(r) and grade_c4(q, r["text"]))
            sc.append({"id": q["id"], "rounds": per,
                       "verdict": "pass" if all(per) else ("flaky" if any(per) else "fail")})
        res["C4"] = sc

    for grp in ("H1", "H2"):
        if grp not in groups:
            continue
        sc = []
        for q in bank.get(grp, []):
            per = []
            for _ in range(rounds):
                r = chat(mid, [{"role": "system", "content": SYSTEM},
                               {"role": "user", "content": q["prompt"]}
                               if grp == "H1" else {"role": "user", "content": q["prompt"]}])
                per.append(valid(r) and grade_h1(q, r["text"]))
            sc.append({"id": q["id"], "rounds": per, "raw_tail": r["text"][:400],
                       "verdict": "pass" if all(per) else ("flaky" if any(per) else "fail")})
        res[grp] = sc
    return res


# ---- 计分 / 报告 -------------------------------------------------------------------

WEIGHTS = {"C1": 25, "C2": 15, "C3": 20, "C4": 10, "H1": 15, "H2": 10}


def score(res):
    cap, detail = 0.0, {}
    for grp, w in WEIGHTS.items():
        items = res.get(grp)
        if not items:
            continue
        if grp == "C3":
            s = 0.0
            for it in items:
                got, tot = (int(x) for x in it["turns_valid"].split("/"))
                s += (12 * it["final_pass"] + 8 * got / tot) / len(items)
        else:
            s = sum(w * (1 if it["verdict"] == "pass" else 0.5 if it["verdict"] == "flaky" else 0)
                    / len(items) for it in items)
        cap += s
        detail[grp] = round(s, 1)
    cap += 5 if res.get("CTX2") else 0
    return round(cap, 1), detail


def safe_name(mid):
    return re.sub(r"[^\w.-]", "_", mid)


def write_report(outdir, mid, meta, res, gates, cap, detail):
    safe = safe_name(mid)
    (outdir / f"report_{safe}.json").write_text(json.dumps(
        {"model": mid, "meta": meta, "gates": gates, "capability": cap,
         "detail": detail, "results": res}, ensure_ascii=False, indent=1))
    md = [f"# 测试报告：{mid}", "",
          f"- 量化精度: {meta['quant']}　形态: {meta['form']}　实际ctx: {meta['actual_ctx']}",
          f"- 投机解码: {meta['spec_resolved']}　KV: {meta['kv_mode']}", "",
          "## 测试时使用的模型参数（全模型统一）", "",
          "**加载参数（POST /v1/load，实际发送）**", "",
          "```json", json.dumps(meta["load_body_sent"], ensure_ascii=False, indent=2), "```", "",
          "**采样参数（每次 chat 请求）**", "",
          "```json", json.dumps(SAMPLING, ensure_ascii=False, indent=2), "```", "",
          f"**系统提示**: `{SYSTEM}`", "",
          "## 门槛", ""]
    md += [f"- {k}: {'✅' if v else '❌'}" for k, v in gates.items()]
    md += ["", f"## 能力分: {cap}/100", "", "```", json.dumps(detail), "```", "",
           "## 明细", "```json", json.dumps(res, ensure_ascii=False, indent=1), "```"]
    (outdir / f"report_{safe}.md").write_text("\n".join(md))
    log("报告已写:", outdir / f"report_{safe}.md")


def test_one(mid, suite, rounds, outdir):
    info = next((m for m in scan_models() if m["id"] == mid), None)
    ok, reason = cache_check(mid)
    if not ok:
        log(f"SKIP {mid}: {reason}")
        return {"model": mid, "skipped": reason}
    unload_all()
    try:
        body_sent, kv_mode, spec, actual_ctx = load_model(mid)
    except Exception as e:
        return {"model": mid, "skipped": f"加载失败: {e}"}
    mid_chat = registered_id(mid)
    if mid_chat != mid:
        log(f"实际注册 id: {mid_chat}")
    meta = {"quant": info["quant"] if info else "-", "form": info["form"] if info else "?",
            "load_body_sent": body_sent, "kv_mode": kv_mode,
            "spec_resolved": spec, "actual_ctx": actual_ctx,
            "registered_id": mid_chat}
    res, gates = {}, {}
    try:
        g0 = chat(mid_chat, [{"role": "system", "content": SYSTEM},
                             {"role": "user", "content": "Reply with exactly: OK"}],
                  max_tokens=512)
        gates["G0"] = valid(g0) and "OK" in g0["text"]
        res["SP"] = speed_probe(mid_chat)
        bank = json.loads((Path(__file__).parent.parent / "question_bank.json")
                          .read_text())
        res.update(run_bank(mid_chat, bank, rounds, suite))
        res["CTX1"] = ctx1(mid_chat)
        gates["CTX1"] = res["CTX1"]["pass"]
        h1 = res.get("H1", [])
        gates["H1>=90%"] = bool(h1) and \
            sum(1 for i in h1 if i["verdict"] != "fail") / len(h1) >= 0.9
        gates["完赛"] = True
        # 单组重跑合并：不丢已有组结果
        prev = outdir / f"report_{safe_name(mid)}.json"
        if prev.exists():
            try:
                p = json.loads(prev.read_text())
                for k, v in p.get("results", {}).items():
                    res.setdefault(k, v)
                for k, v in p.get("gates", {}).items():
                    gates.setdefault(k, v)
            except Exception:
                pass
        cap, detail = score(res)
    finally:
        unload_all()
    write_report(outdir, mid, meta, res, gates, cap, detail)
    return {"model": mid, "meta": {k: meta[k] for k in
            ("quant", "form", "kv_mode", "spec_resolved", "actual_ctx")},
            "gates": gates, "capability": cap,
            "speed": res.get("SP", {})}


# ---- leaderboard ---------------------------------------------------------------

def cmd_leaderboard(args):
    outdir = Path(args.dir)
    rows = []
    for f in sorted(outdir.glob("report_*.json")):
        r = json.loads(f.read_text())
        g = r["gates"]
        ok = g.get("G0") and g.get("CTX1") and g.get("H1>=90%")
        rows.append((r, ok))
    ok_rows = [r for r, ok in rows if ok]
    mx = max((r["results"]["SP"].get("decode_tps") or 0) for r in ok_rows) if ok_rows else 1
    ok_rows.sort(key=lambda r: (-r["capability"],
                                -(r["results"]["SP"].get("decode_tps") or 0)))
    lines = ["| 排名 | 模型 | 量化 | 形态 | 实际ctx | 投机档位 | 能力分 | decode tok/s | TTFT(s) |",
             "|---|---|---|---|---|---|---|---|---|"]
    for i, r in enumerate(ok_rows, 1):
        sp = r["results"]["SP"]
        m = r["meta"]
        lines.append(f"| {i} | {r['model']} | {m['quant']} | {m['form']} | "
                     f"{m['actual_ctx']} | {m['spec_resolved']} | {r['capability']} | "
                     f"{sp.get('decode_tps')} | {sp.get('ttft_s')} |")
    dnf = [r["model"] for r, ok in rows if not ok]
    if dnf:
        lines += ["", "未入榜（门槛失败）：" + ", ".join(dnf)]
    out = "\n".join(lines)
    (outdir / "leaderboard.md").write_text(out)
    print(out)


# ---- CLI ------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("models", help="扫描已部署模型并编号（给用户选）")
    rp = sub.add_parser("run", help="按序号/模型跑评测")
    rp.add_argument("--pick", help="模型序号，逗号分隔，如 1,3,5（对应 models 子命令输出）")
    rp.add_argument("--model", action="append", help="直接指定模型 id（可重复）")
    rp.add_argument("--all", action="store_true")
    rp.add_argument("--suite", choices=["quick", "full", "ctx1", "h1"], default="full")
    rp.add_argument("--rounds", type=int, default=3)
    rp.add_argument("--resume", action="store_true")
    rp.add_argument("--outdir", default=str(REPO / "eval-results"
                                           / time.strftime("%Y%m%d")))
    lb = sub.add_parser("leaderboard")
    lb.add_argument("--dir", default=str(REPO / "eval-results"
                                         / time.strftime("%Y%m%d")))
    args = ap.parse_args()

    if args.cmd == "models":
        cmd_models(args)
    elif args.cmd == "leaderboard":
        cmd_leaderboard(args)
    elif args.cmd == "run":
        outdir = Path(args.outdir)
        outdir.mkdir(parents=True, exist_ok=True)
        models = scan_models()
        if args.pick:
            sel = pick_models(args.pick)
        elif args.model:
            sel = args.model
        else:
            sel = [m["id"] for m in models]
        results = []
        for mid in sel:
            done = outdir / f"report_{safe_name(mid)}.json"
            if args.resume and done.exists():
                log("跳过(已完成):", mid)
                continue
            log("==== 测试", mid, "====")
            r = test_one(mid, args.suite, args.rounds, outdir)
            if r.get("skipped"):
                (outdir / f"skipped_{safe_name(mid)}.json").write_text(
                    json.dumps(r, ensure_ascii=False))
            results.append(r)
        print(json.dumps([r for r in results if not r.get("skipped")],
                         ensure_ascii=False, indent=1))
        cmd_leaderboard(argparse.Namespace(dir=str(outdir)))


if __name__ == "__main__":
    main()
