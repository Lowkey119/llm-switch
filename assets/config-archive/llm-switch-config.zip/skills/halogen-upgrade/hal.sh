#!/bin/bash
# hal.sh — 任意路径下管理 halogen 推理服务（podman 容器 halogen, :8731）
#
# 用法：
#   hal.sh            # 重启，后台运行，并等待就绪
#   hal.sh start      # 启动（已在跑则先重启）
#   hal.sh stop       # 只停止
#   hal.sh status     # 查看状态（进程/端口/API）
#   hal.sh log        # 实时日志：默认中文可读版 + info 级（只看预处理/生成速率）
#   hal.sh log raw    # 实时日志：原始原文
#   hal.sh log N      # 实时日志，先回看最近 N 行（可组合：hal.sh log 100 raw）
#   hal.sh log debug  # 等级：info=速率行 | debug=+请求体与输出内容 | trace=全部（也可给 N 组合）
#   hal.sh dash       # 启动 Web 控制台（:8739，浏览器打开看状态/指标/日志）
#   hal.sh dash stop  # 关闭控制台
#
# 任意路径可用：脚本自带定位（优先脚本所在目录，其次 /mnt/data/haloen），
# 已软链到 ~/.local/bin/hal.sh 全局可用。
set -u

SELF=$(readlink -f "$0")
HERE=$(dirname "$SELF")
if [ -f "$HERE/run-halogen.sh" ]; then
  PROJ="$HERE"
elif [ -f /mnt/data/haloen/run-halogen.sh ]; then
  PROJ=/mnt/data/haloen
else
  echo "错误：找不到 halogen 部署目录（run-halogen.sh）" >&2
  exit 1
fi

RUN="$PROJ/run-halogen.sh"
NAME="halogen"
# 端口跟 halogen.env 走（控制台可改），默认 8731
API_PORT="${HALOGEN_HOST_PORT:-$(grep -E '^HALOGEN_HOST_PORT=' "$PROJ/halogen.env" 2>/dev/null | tail -1 | cut -d= -f2-)}"
API_PORT="${API_PORT:-8731}"
API="http://127.0.0.1:$API_PORT/v1/models"
# 权重 118GB 冷读盘 pin 权重较慢（实测约 3 分钟），上限给足
READY_TIMEOUT=900

usage() { sed -n '2,17p' "$SELF" | sed 's/^# \{0,1\}//'; }

DASH_PORT="${HALOGEN_DASH_PORT:-8739}"

do_dash() {
  local script="$PROJ/hal_dash.py"
  [ -f "$script" ] || { echo "错误：找不到 $script" >&2; exit 1; }
  # systemd 用户服务优先（开机自启；unit 由部署时安装）
  if systemctl --user is-enabled hal-dash.service >/dev/null 2>&1; then
    if [ "${2:-}" = "stop" ]; then
      systemctl --user stop hal-dash.service && echo "控制台已关闭"
    else
      systemctl --user restart hal-dash.service \
        && echo "控制台已启动：http://<本机IP>:$DASH_PORT/（systemd 用户服务，开机自启）"
    fi
    return
  fi
  if [ "${2:-}" = "stop" ]; then
    pkill -f "[h]al_dash.py" 2>/dev/null && echo "控制台已关闭" || echo "控制台本来就没开"
    return
  fi
  if pkill -f "[h]al_dash.py" 2>/dev/null; then sleep 1; fi
  setsid nohup python3 "$script" "$DASH_PORT" >"$PROJ/logs/hal-dash.log" 2>&1 </dev/null &
  sleep 1
  if pkill -0 -f "[h]al_dash.py" 2>/dev/null; then
    echo "控制台已启动：http://<本机IP>:$DASH_PORT/ （关闭：hal.sh dash stop）"
  else
    echo "启动失败，日志尾部：" >&2
    tail -n 10 "$PROJ/logs/hal-dash.log" 2>&1 >&2
    return 1
  fi
}

do_stop() {
  if ! podman ps -a --format '{{.Names}}' 2>/dev/null | grep -qx "$NAME"; then
    echo "服务本来就没在跑"
    return 0
  fi
  bash "$RUN" stop >/dev/null 2>&1
  # 容器 stop 超时后 run-halogen 不会 rm，这里确保彻底清掉以便干净重启
  podman rm -f "$NAME" >/dev/null 2>&1
  echo "已停止"
}

wait_ready() {
  local t=0
  echo "启动中（118GB 权重冷加载约 1~5 分钟）"
  while [ "$t" -lt "$READY_TIMEOUT" ]; do
    if curl -s -m 3 "$API" 2>/dev/null | grep -q "halogen"; then
      echo " 就绪（${t}s）：$API"
      return 0
    fi
    # 容器消失 = 启动失败（entrypoint 报错退出）
    if ! podman ps --format '{{.Names}}' 2>/dev/null | grep -qx "$NAME"; then
      echo
      echo "启动失败（容器已退出），日志尾部："
      podman logs --tail 20 "$NAME" 2>&1
      return 1
    fi
    sleep 3
    t=$((t + 3))
    printf '.'
  done
  echo
  echo "等待 ${READY_TIMEOUT}s 仍未就绪，日志尾部："
  podman logs --tail 20 "$NAME" 2>&1
  return 1
}

do_status() {
  echo "== 容器 =="
  podman ps -a --filter name="$NAME" --format "{{.Names}}  {{.Status}}" || true
  echo "== 端口 =="
  ss -ltn | grep ":$API_PORT" || echo "$API_PORT 未监听"
  echo "== API =="
  curl -s -m 3 "$API" || echo "API 无响应"
  echo
  echo "== 资源 =="
  podman stats --no-stream --format "{{.Name}}  CPU {{.CPUPerc}}  内存 {{.MemUsage}}" "$NAME" 2>/dev/null || true
  free -g | sed -n '2p' | awk '{printf "主机可用内存: %sG\n", $7}'
}

do_start() {
  # [互斥守卫] 102 统一 128G 内存只承载一个引擎：gufo 在跑就先停（容器化部署 2026-11-02）
  if podman ps --format '{{.Names}}' 2>/dev/null | grep -qx gufo; then
    echo "[互斥] gufo 容器在跑，先停止它..."
    podman stop -t 45 gufo >/dev/null
  fi
  do_stop
  bash "$RUN" start || return 1
  wait_ready || exit 1
}

case "${1:-restart}" in
  -h | --help | help)
    usage
    ;;
  stop)
    do_stop
    ;;
  status | st)
    do_status
    ;;
  log)
    # 用法: hal.sh log [行数] [info|debug|trace] [raw] — 默认中文可读版 + info 级
    N=40
    RAW=0
    LEVEL="info"
    for a in "${@:2}"; do
      case "$a" in
        raw) RAW=1 ;;
        info | debug | trace) LEVEL="$a" ;;
        *[!0-9]*) echo "未知参数：$a" >&2; exit 1 ;;
        *) N="$a" ;;
      esac
    done
    TRANSLATOR="$PROJ/hal_log_cn.py"
    if [ "$RAW" = 1 ] || [ ! -f "$TRANSLATOR" ]; then
      [ "$RAW" = 0 ] && echo "翻译器缺失，回退原始日志"
      echo "跟踪原始日志：$NAME（回看 $N 行，Ctrl+C 退出）"
      exec podman logs -t --tail "$N" -f "$NAME"
    fi
    echo "跟踪可读日志：$NAME（等级 $LEVEL，回看 $N 行，Ctrl+C 退出；raw=原文）"
    podman logs -t --tail "$N" -f "$NAME" | python3 "$TRANSLATOR" "$LEVEL"
    ;;
  start | restart | "" | -b | --bg)
    do_start
    ;;
  dash)
    do_dash "$@"
    ;;
  *)
    echo "未知参数：$1" >&2
    usage >&2
    exit 1
    ;;
esac
