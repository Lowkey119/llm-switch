#!/usr/bin/env bash
# halogen-flash-server 0.16.0 部署脚本（权重已在 /mnt/haloen/models，不走下载）
# 用法: bash run-halogen.sh [start|stop|status|log]
set -u
IMG="ghcr.io/peonist-ai/halogen-flash-server:0.20.2"
NAME="halogen"
# 与 gfx1151 互斥运行（内存不允许共存），halogen 直接占用 8731
PORT_MAP="${HALOGEN_HOST_PORT:-8731}:8731"
MODELS=/mnt/haloen/models
PROJ=/mnt/haloen

# 与容器同一份参数来源：转发端口等部署项也写在 halogen.env（控制台可改）
if [ -f "$PROJ/halogen.env" ]; then
  set -a
  # shellcheck disable=SC1091
  . "$PROJ/halogen.env"
  set +a
fi
# 宿主机转发端口 → 容器内 8731（HALOGEN_API_PORT）
PORT_MAP="${HALOGEN_HOST_PORT:-8731}:8731"

case "${1:-start}" in
  start)
    podman rm -f "$NAME" >/dev/null 2>&1
    # 参数集中放 halogen.env（--env-file），改后需重启生效。
    # sitecustomize.py：请求体/输出内容日志（debug 级数据源），挂到镜像的
    # site-packages；镜像升级 Python 小版本若变，需同步改这个路径。
    setsid nohup podman run -d --name "$NAME" \
      --device /dev/kfd --device /dev/dri --group-add keep-groups \
      --ipc=host --ulimit memlock=-1:-1 \
      --env-file "$PROJ/halogen.env" \
      -v "$PROJ/sitecustomize.py":/usr/local/lib/python3.12/site-packages/sitecustomize.py:ro \
      -v "$MODELS":/models \
      -p "$PORT_MAP" \
      "$IMG" > "$PROJ/halogen-start.log" 2>&1
    sleep 3
    podman ps --filter name="$NAME" --format "{{.Status}}"
    echo "日志: podman logs -f $NAME"
    ;;
  stop)  podman stop -t 60 "$NAME" 2>&1 ;;
  status) podman ps -a --filter name="$NAME" --format "{{.Names}} {{.Status}}"; curl -s -m 3 http://127.0.0.1:8731/v1/models || true ;;
  log)   podman logs -f "$NAME" ;;
  *) echo "用法: $0 [start|stop|status|log]"; exit 1 ;;
esac
