---
name: halogen-upgrade
description: 查询 halogen-flash-server（peonist-ai）上游新版本与 CHANGELOG 新特性，读取 102（lowkey@192.0.2.10）podman 容器实际部署的版本与参数，逐项判断是否符合"编码场景推荐配置"与新版官方文档，给出建议书；经用户确认后用 hal-ver.sh 升级镜像、同步更新 halogen.env 参数并验证服务、可回滚。Use when 用户说"检查 halogen 新版本/上游更新了什么"、"halogen 参数设置对不对/符不符合编码场景"、"把 102 上的 halogen 升到最新"、"升级 halogen 并更新参数"。
---

# halogen-upgrade — 查新版本 → 参数合规判断 → 确认后升级

## 定位与铁律

你是 halogen-flash-server 的版本与参数管家。工作分两段：**前半段全程只读**（查上游、读部署现状、逐项比对、出建议书）；**后半段动手指在用户明确确认之后**。

1. **硬闸门**：未获用户对建议清单的明确确认，不改 102 上任何文件、不 pull、不重启。用户只问"更新了什么"时，做完只读阶段就停。
2. **全程中文**，汇报面向人读，不堆原始 JSON。
3. **先复用，不造轮子**：版本切换用 `hal-ver.sh`，启停用 `hal.sh`，参数只写 `halogen.env`。禁止自写 podman run、绕过脚本改 `IMG=` 行。
4. **外部事实以运行时核实为准**，下表坐标是入口不是答案；发现实况与本文不符，先按实况走，并在汇报里指出坐标过期。
5. **权重永不重下**：`HALOGEN_DOWNLOAD` 必须保持为空；`/mnt/haloen/models`（约 118GB）只读挂载，绝不 rm/覆盖。
6. **改参数必先备份**（`halogen.env.bak-$(date +%Y%m%d-%H%M%S)`），升级前先钉版本备份槽。

## 事实坐标（集中定义；用时核实）

| 事物 | 坐标 |
| --- | --- |
| 上游仓库 | `github.com/peonist-ai/halogen-flash-server`；**只有 tag、没有 GitHub Releases 页**，权威变更在 `CHANGELOG.md` |
| 最新 tag 查询 | `https://api.github.com/repos/peonist-ai/halogen-flash-server/tags?per_page=5` |
| CHANGELOG 取法 | `https://api.github.com/repos/peonist-ai/halogen-flash-server/contents/CHANGELOG.md` → JSON 的 `content` 字段是 base64（本机 raw.githubusercontent.com 会超时，**走 api.github.com，别走 raw**） |
| 任意 tag 的文档 | `.../contents/docs/FLAGS.md?ref=vX.Y.Z`（同为 base64） |
| 目标机 | `ssh 102`（~/.ssh/config 别名 → lowkey@192.0.2.10，密钥免密；也可写全 `lowkey@192.0.2.10`） |
| 部署目录 | 102 上 `/mnt/haloen`。**以 `podman inspect halogen` 的 Mounts 实测为准**；`/mnt/data/haloen` 是 2026-10-11 的归档旧副本（IMG/env 可能过期），只读参考，不当现状 |
| 版本指针 | `/mnt/haloen/run-halogen.sh` 第 5 行 `IMG="ghcr.io/peonist-ai/halogen-flash-server:X.Y.Z"` |
| 参数文件 | `/mnt/haloen/halogen.env`（`--env-file` 注入；Web 控制台 `hal_dash.py` "参数"面板读写同一文件；改后必须重启才生效） |
| 现成工具 | `bash /mnt/haloen/hal-ver.sh show\|set <x.y.z>\|backup\|restore`；`hal.sh [start\|stop\|status\|log]`（已软链 `~/.local/bin/hal.sh`，任意路径可用） |
| 容器 | podman，名 `halogen`，宿主 8731 → 容器 8731，mode `all`，挂 `/mnt/haloen/sitecustomize.py` 与 `/mnt/haloen/models` |
| 健康端点 | `ssh 102 'curl -s -m 5 http://127.0.0.1:8731/health'` → `version.api/engine/match`、`slots`、`context`、`decode`、`drafters_available`；另有 `/v1/models` |
| 冷启动 | 118GB 权重冷读约 1~5 分钟，`hal.sh` 就绪等待上限 900s——升级期间服务会中断，必须提前告知用户 |
| 互斥拓扑 | qwenox / halogen / Strata 三引擎互斥占 8731（模型 ID 统一 `qwen3.8-flash-next`）。升级只动 halogen；若当前 8731 上跑的是别的引擎，停下来问用户 |
| 镜像拉取绕行 | 102 直连 ghcr.io 的 blob 通道只有 ~0.1 MB/s 且频繁 EOF/500/静默挂起（API 端点不受影响，仍快）。**压缩层总共仅 ~930MB**（3.6GB 是解压后尺寸，ETA 按压缩算）。2026-11-06 实测：`ghcr.dockerproxy.net` ~5 MB/s（不支持 Range）；`ghcr.nju.edu.cn` manifest 可达但 blob 端点超时；`ghcr.m.daocloud.io` / `ghcr.1ms.run` / `ghcrproxy.com` 等公共镜像全灭。pull 涓流 → 走阶段五b 的 `fetch_image.sh` |

## 阶段一：读部署现状（只读）

```bash
ssh 102 'cd /mnt/haloen && bash hal-ver.sh show'          # 当前 IMG tag + 本地镜像 + 备份槽
ssh 102 'podman inspect halogen --format "{{.Config.Image}}
Mounts: {{range .Mounts}}{{.Source}}=>{{.Destination}} {{end}}
Env:{{range .Config.Env}} {{.}}{{end}}"'                   # 实际镜像、挂载、注入的全部环境变量
ssh 102 'cat /mnt/haloen/halogen.env'                      # 参数全集（含注释里的自述依据）
ssh 102 'curl -s -m 5 http://127.0.0.1:8731/health'        # 运行时实况：version/slots/context/decode
ssh 102 'cd /mnt/haloen && bash hal.sh status'             # 容器/端口/API/资源
```

四路信息要互相对账：`IMG=` 行、`/health` 的 `version.api` 与 `version.engine`（还须 `match:true`）、容器 Env、`halogen.env` 文件。对不上就先查清（多半是改了 env 没重启，或改了 IMG 没重启），带着实况进阶段二。

## 阶段二：查上游新版本与新特性（只读）

1. 取最新 tag，与部署 tag 比较。
   - **相同** → 汇报"已是最新"，仍可顺手读 CHANGELOG 顶部有无未发版说明；**流程到此为止，不升级**（除非用户另有指示）。
   - **不同** → 继续。
2. 拉 `CHANGELOG.md`（base64 解码），抽出 **部署版之后的所有版本段**（如部署 0.18.10、最新 0.18.11，就抽 0.18.11 段）。
3. 按 Added / Changed / Fixed 三栏提炼新特性，人话摘要 + 关键收益数字（性能行、精度行）。
4. 抓 **flag 级变更**：段落与 diff 中新出现/改名/改默认值的 `HALOGEN_*` 变量；需要取值域与默认值时拉该 tag 的 `docs/FLAGS.md`。
5. 顺带记录"输出兼容性"声明（该项目惯例：temperature 0 输出逐字节不变），这是劝用户放心升级的依据。

## 阶段三：参数合规判断（编码场景，只读）

**判断基准**（三层，逐条对）：① 新版 `FLAGS.md` 的默认值/取值域/新增废弃；② CHANGELOG 对行为的改动；③ `halogen.env` 头部自述的"编码场景推荐配置"（greedy 可复现、xhigh 推理、prompt cache、并发槽位）。

**必查清单**：

| 检查项 | 判什么 |
| --- | --- |
| 版本一致性 | `IMG=` / `/health` version / 容器 Env `HALOGEN_IMAGE_VERSION` 三者一致且 `match:true`；env 头注释的版本号是否已过期（注释跟不上版本 = 低风险"过时"，不算违规） |
| 下载保护 | `HALOGEN_DOWNLOAD` 为空（非空 = **高危**，升级后会触发 111GB 重下） |
| 编码可复现 | `HALOGEN_TEMPERATURE=0`（greedy）与 `HALOGEN_REASONING_EFFORT`（编码场景声明 xhigh）符合自述；`decode` 行与之吻合 |
| 并发与投机 | `HALOGEN_KV_SLOTS` 与新版 `HALOGEN_SPEC_GROUP`（0.18.11 起）的交互：3~4 路投机需 slots≥3，5 路起退回普通 batch；槽位数还牵动单流速度与显存 |
| 上下文/输出预算 | `HALOGEN_CTX`（262144 = 模型原生上限）、`HALOGEN_MAX_TOK`、`HALOGEN_MAX_TOKENS_CAP` 三者关系仍满足新版约束（关系变了 = 建议调整） |
| 缓存 | `HALOGEN_PROMPT_CACHE` 取值语义在新版没变（mode 2 = resume-anywhere） |
| 草稿/预填 | `HALOGEN_DRAFTER_DEFAULT`、`HALOGEN_PREFILL_CHUNK` 与新版默认/建议一致 |
| 视觉 | `HALOGEN_VISION_TOWER=1`（图片请求入口） |
| 新增 flag | 新版引入的 `HALOGEN_*`（如 0.18.11 的 `HALOGEN_SPEC_GROUP`、`HALOGEN_ACCESS_LOG`）：不设 = 吃新版默认，通常合规；但要在判断表里**显式列出**，让用户知道默认值是什么 |
| 注释与值 | env 注释与实际值矛盾处（如"设为 2"旁边值是 4）标为"注释失真"，建议顺手改 |

**现网基线**（2026-10-19 实测 0.18.10，仅作参照，**每次运行以阶段一实读为准**）：
`TEMPERATURE=0`、`REASONING_EFFORT=xhigh`、`KV_SLOTS=4`、`CTX=262144`、`MAX_TOK=32768`、`MAX_TOKENS_CAP=65536`、`DRAFTER_DEFAULT=1`、`PROMPT_CACHE=2`、`PREFILL_CHUNK=32768`、`VISION_TOWER=1`、`MODEL_ID=qwen3.8-flash-next`、`QUEUE_TIMEOUT=3600`。

**产出三态判断表**：每行 = 参数 | 现值 | 新版基准 | 结论（✅合规保持 / ⚠️过时-仅注释 / 🔧建议调整）| 理由与影响。

## 阶段四：建议书 + 硬闸门

建议书必须包含：

1. **新特性摘要**（部署版 → 最新版，三栏提炼）。
2. **三态判断表**（阶段三产出）。
3. **拟执行改动清单**：镜像 tag 变更、参数逐条（`键: 旧值 → 新值` + 理由 + 影响面）、哪些只是"吃默认不动"。
4. **代价与风险**：服务中断时长（冷加载 1~5 分钟）、回滚坐标（备份槽版本 + env 备份文件名）。

然后**停下等确认**。用户逐项改需求就按他改；拿到明确"可以/执行"之前，不碰任何东西。

## 阶段五：执行升级（仅在确认后）

```bash
# 0) 前置：确认 8731 上跑的确实是 halogen（互斥拓扑，跑着别的引擎先问用户）
ssh 102 'cd /mnt/haloen && bash hal.sh status'

# 1) 钉当前版本到永久备份槽（回滚锚点）
ssh 102 'cd /mnt/haloen && bash hal-ver.sh backup'

# 2) 若有参数改动：备份 → 改 /mnt/haloen/halogen.env（仅改确认过的键，保留其余行与注释）
ssh 102 'cd /mnt/haloen && cp halogen.env halogen.env.bak-$(date +%Y%m%d-%H%M%S)'
#   改法：scp 出来改完传回，或 102 上原地编辑；一次只改确认过的键

# 3) 切版本（自动：缺镜像先 pull（压缩 ~930MB）→ 改 run-halogen.sh 的 IMG= → 在跑则经 hal.sh 重启并等就绪）
ssh 102 'cd /mnt/haloen && bash hal-ver.sh set X.Y.Z'
#   只改参数不换版本时，跳过本步，改用：ssh 102 'cd /mnt/haloen && bash hal.sh'
```

⚠️ **pull 可能涓流数小时或静默挂起（见阶段五b），且 `hal-ver.sh set` 全程含冷加载就绪等待，
不要塞进前台 ssh 超时里跑**（超时被杀 = exit 143，白干）。标准姿势：102 上 `nohup bash -c "..." > /tmp/xxx.log 2>&1 &`，
本地 `sleep N && ssh 102 'tail /tmp/xxx.log'` 轮询。

## 阶段五b：镜像拉取涓流/断流绕行手册（2026-11-06 实测，0.18.23→0.19.1）

**症状**：`hal-ver.sh set` 的 pull 以 0.1~0.4 MB/s 涓流、EOF / HTTP 500，或"进程活着但 rx_bytes=0"
的静默挂起。podman 挂起的连接**不报错**，纯靠退出码的 retry 循环救不回来——重试循环必须
`timeout 240 podman pull ...` 包一层才能跳出挂死连接。

**诊断三板斧**（确认瓶颈再绕行，别瞎重试）：

```bash
# ① 镜像存活探测——注意 manifest 可达 ≠ blob 快，不能拿它下结论
ssh 102 'timeout 12 podman manifest inspect <镜像前缀>/peonist-ai/halogen-flash-server:X.Y.Z' \
  && echo REACHABLE || echo fail
# ② blob 真实速度：token 后对最大 blob 发 Range 请求测吞吐
ssh 102 'T=$(curl -sm 20 "https://ghcr.io/token?scope=repository:peonist-ai/halogen-flash-server:pull" | python3 -c "import sys,json;print(json.load(sys.stdin)[\"token\"])"); \
  curl -sLm 25 -H "Authorization: Bearer $T" -r 0-8000000 -o /dev/null -w "%{speed_download} B/s code=%{http_code}\n" \
  "https://<候选>/v2/peonist-ai/halogen-flash-server/blobs/<最大层digest>"'
# ③ 连接死活：rx_bytes 两次采样隔 10s，0 增长 = 挂起
ssh 102 'A=$(cat /sys/class/net/*/statistics/rx_bytes | paste -sd+ | bc); sleep 10; \
  B=$(cat /sys/class/net/*/statistics/rx_bytes | paste -sd+ | bc); echo $(( (B-A)/1024/1024 ))MB'
```

**绕行方案**：本技能脚本 `fetch_image.sh`（scp 到 102 跑，nohup 后台 + 轮询日志，实测 ~6 分钟）：

```bash
scp ~/.config/opencode/skills/halogen-upgrade/fetch_image.sh 102:/tmp/
ssh 102 'nohup bash /tmp/fetch_image.sh X.Y.Z > /tmp/fetch_X.Y.Z.log 2>&1 & echo $!'
# 日志出现 IMAGE_READY 后，正常走阶段五第 3 步：hal-ver.sh set 见本地已有镜像会跳过 pull
```

原理：manifest 走 ghcr.io（API 快），blob 自动探测最快镜像后 curl 逐个下载 + sha256 校验，
组装 OCI 布局后 `podman pull oci:` 导入，tag 成 `ghcr.io/peonist-ai/halogen-flash-server:X.Y.Z`
官方名——**不碰 `IMG=` 行、不绕过 hal-ver.sh**，铁律 3 不破。

**坑清单**（全部踩过）：

- **`pkill -f` 自杀**：over-ssh 时 pattern 会匹配 ssh 会话自身的命令行（命令行里含同样字符串），
  会话先被杀（exit 255），后续命令没跑。用 `pgrep` 拿显式 PID 再 `kill`，或确保 pattern 不匹配自身。
- **podman pull 挂起是静默的**：进程在、无输出、不报错，rx_bytes 采样是唯一可靠判据。
- **ghcr token ~5 分钟过期**：每个 blob 下载前重取 token，别一个 token 用到底。
- **镜像多半不支持 Range**（返回 200 而非 206）：`curl -C -` 断点续传失效 → 整层下载 + sha256
  校验 + 整层重试；压缩层小，整层重试代价可忽略。
- **podman 的 `oci:` transport 拒收 docker MIME 类型**：报 `matches unsupported manifest MIME types`，
  须把 manifest 的 mediaType 转成 OCI 等价类型、重算 manifest 摘要、重写 index.json（脚本已处理；
  config blob 字节不变，导入后 image ID 与上游一致）。
- **压缩尺寸 ≠ 落盘尺寸**：下载只有 ~930MB，3.6GB 是解压后；按 3.6GB 估 ETA 会误判"没在动"。
- **成功后清理**：`rm -rf /tmp/hal_fetch_X.Y.Z`（~1GB 临时 blob）。

## 阶段六：验证与冒烟（执行后必做，拿证据再汇报）

```bash
ssh 102 'curl -s -m 5 http://127.0.0.1:8731/health'   # version.api/engine = 新版 且 match:true；slots/context 与预期一致
ssh 102 'curl -s -m 5 http://127.0.0.1:8731/v1/models'
# 冒烟：一次最小 greedy 请求（模型 ID 以 halogen.env 的 HALOGEN_MODEL_ID 为准）
ssh 102 'curl -s -m 60 http://127.0.0.1:8731/v1/chat/completions -H "content-type: application/json" -d "{\"model\":\"qwen3.8-flash-next\",\"messages\":[{\"role\":\"user\",\"content\":\"只回复两个字母：ok\"}],\"max_tokens\":16,\"temperature\":0}"'
```

⚠️ 冒烟判读：这是推理模型，`max_tokens=16` 可能全被 `reasoning_content` 吃掉，返回
`finish_reason:"length"` 且 `content` 为空——**属预期，不是失败**。判成功看：HTTP 200、
`usage` 有 token 计数、`timings` 的 prompt/decode 速率正常。想看正文把 `max_tokens` 放大到 64+。

全部通过 → 汇报：新特性、判断表终态、改动清单、验证证据（/health 原文关键行）、回滚坐标（`hal-ver.sh restore` + env 备份文件名）。

**失败回滚**：容器起不来或冒烟失败 → `bash hal-ver.sh restore`（或手动 set 回备份槽版本）+ 恢复 `halogen.env.bak-*` + `bash hal.sh`，然后把失败日志尾部（`hal.sh log 50 raw`）如实汇报。

## 收尾（可选，须先问）

本技能真身由 llm-switch 统一管理与存放：`~/.llm-switch/skills/halogen-upgrade/`，各代理（opencode / pi 等）的 skills 目录下只放软链引用，**勿在软链目录里另存实体**。目录内 `run-halogen.sh` / `halogen.env` 兼作本地归档副本（2026-10-11 同步的旧件，IMG 还是 0.18.6、参数与现网不符），升级成功后可询问用户是否从 102 拉回同步（`scp 102:/mnt/haloen/{run-halogen.sh,halogen.env} ~/.llm-switch/skills/halogen-upgrade/`）；`myllm/README.md` 里 halogen 一节若有版本表述也提醒更新。
