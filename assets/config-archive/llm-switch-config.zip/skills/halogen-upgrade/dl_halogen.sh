#!/bin/bash
# 下载 halogen 官方权重（v2 启动所需集，约 111GiB），走 hf-mirror，curl 断点续传
# - 已存在且大小一致的文件跳过；不一致则断点续传
# - --speed-limit/--speed-time：连接低于 200KB/s 持续 60s 即断开。
#   实测同一镜像新连接 ~950KB/s 而被限流的旧连接只有 ~130KB/s，
#   快速断开换新连接是突破限流的主要手段（外层守护负责重试）
# - 文件间歇 20s，避免限流期间高频重连被封
set -u
BASE="https://hf-mirror.com/peonist-ai/halogen-qwen3.8-flash-next/resolve/main"
DEST="/mnt/data/haloen/models"
mkdir -p "$DEST/tokenizer"

FILES=(
  qwen38-flash-next-v2.hgn
  qwen38-flash-next-ngram.hgn
  qwen38-flash-next-mtp.hgn
  qwen38-flash-next-vision.hgn
  tokenizer/tokenizer.json
  tokenizer/vocab.json
  tokenizer/merges.txt
  tokenizer/tokenizer_config.json
  tokenizer/chat_template.jinja
  tokenizer/generation_config.json
)

remote_size() {
  curl -fsIL -m 30 "$1" 2>/dev/null | tr -d '\r' \
    | awk 'tolower($1)=="content-length:"{s=$2} END{print s}'
}

ok=0; skip=0; fail=0
for f in "${FILES[@]}"; do
  out="$DEST/$f"
  want=$(remote_size "$BASE/$f")
  have=$(stat -c %s "$out" 2>/dev/null || echo 0)
  # 远端大小取不到（限流/错误页）时不跳过、交给 curl 续传
  if [ -n "$want" ] && [ "$want" = "$have" ]; then
    echo "[skip] $f ($have)"
    skip=$((skip+1)); continue
  fi
  echo "[get ] $f  已有 $have / $want"
  if curl -fL --retry 5 --retry-delay 10 --connect-timeout 20 \
       --speed-limit 204800 --speed-time 60 \
       -C - -sS --show-error \
       -o "$out" "$BASE/$f"; then
    ok=$((ok+1))
  else
    echo "[FAIL] $f" >&2
    fail=$((fail+1))
    sleep 20   # 失败后退避，减轻限流压力
  fi
done
echo "DONE ok=$ok skip=$skip fail=$fail"
[ "$fail" -eq 0 ]
