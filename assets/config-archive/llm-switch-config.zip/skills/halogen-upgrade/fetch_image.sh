#!/bin/bash
# fetch_image.sh — ghcr.io 直连涓流/断流时，把 halogen-flash-server 镜像弄进 102 的 podman
# 用法（scp 到 102 后在 102 上跑，建议 nohup 后台 + 轮询日志）：
#   scp fetch_image.sh 102:/tmp/ && ssh 102 'nohup bash /tmp/fetch_image.sh X.Y.Z > /tmp/fetch_X.Y.Z.log 2>&1 &'
# 原理：ghcr.io 的 API 端点快、只有 blob 传输慢 → manifest 走 ghcr.io，blob 探测最快镜像后
#       curl 逐个下载 + sha256 校验 → 组装 OCI 布局 → podman pull oci: 导入 → tag 成 ghcr.io 官方名。
# 导入后 `hal-ver.sh set X.Y.Z` 见本地已有镜像会跳过 pull，直接切 IMG 重启。
# 2026-11-06 实测（0.18.23→0.19.1）：ghcr.io 直连 ~0.1MB/s 且频繁 EOF/500，本脚本走
# ghcr.dockerproxy.net 5MB/s，全程约 6 分钟。
set -u
TAG=${1:?用法: bash fetch_image.sh X.Y.Z}
D=/tmp/hal_fetch_$TAG
REG=ghcr.io
REPO=peonist-ai/halogen-flash-server
# 候选镜像（探测后取最快；实测多数公共镜像已死，列表按存活概率排）
MIRRORS="ghcr.dockerproxy.net ghcr.nju.edu.cn $REG"
mkdir -p "$D/blobs/sha256"

get_token() {
  curl -sm 20 "https://$REG/token?scope=repository:$REPO:pull" \
    | python3 -c "import sys,json;print(json.load(sys.stdin)['token'])"
}

# 1) manifest（ghcr.io API 端点快，与 blob 限速无关）
T=$(get_token)
curl -s -H "Authorization: Bearer $T" \
  -H "Accept: application/vnd.docker.distribution.manifest.v2+json, application/vnd.oci.image.manifest.v1+json" \
  "https://$REG/v2/$REPO/manifests/$TAG" -o "$D/manifest.json"
grep -q layers "$D/manifest.json" || { echo MANIFEST_FAIL; exit 1; }
BIG=$(python3 -c "import json;m=json.load(open('$D/manifest.json'));print(max(m['layers'],key=lambda l:l['size'])['digest'])")

# 2) 探测各镜像 blob 真实速度（manifest 可达 ≠ blob 快，必须用真 blob 测）
#    镜像多半不支持 Range（返回 200），curl -r 会整层下到超时——speed_download 仍能测出吞吐
BEST=""; BESTSP=0
for m in $MIRRORS; do
  SP=$(curl -sLm 20 -H "Authorization: Bearer $T" -r 0-8000000 -o /dev/null \
       -w "%{speed_download}" "https://$m/v2/$REPO/blobs/$BIG" 2>/dev/null | cut -d. -f1)
  SP=${SP:-0}
  echo "probe $m: $((SP/1024)) KB/s"
  if [ "$SP" -gt "$BESTSP" ]; then BESTSP=$SP; BEST=$m; fi
done
[ "$BESTSP" -ge 102400 ] || { echo "所有镜像都 <100KB/s，先人工找新镜像再跑"; exit 1; }
echo "选用镜像: $BEST ($((BESTSP/1024)) KB/s)"

# 3) 逐 blob 下载：整层下载 + sha256 校验 + 整层重试（镜像不支持 Range，断点续传无意义；
#    压缩层总共 ~930MB，快的镜像上单层几秒，整层重试代价小）
python3 -c "
import json
m=json.load(open('$D/manifest.json'))
print(m['config']['digest'])
for l in m['layers']: print(l['digest'])
" > "$D/digests.txt"
TOTAL=$(wc -l < "$D/digests.txt"); N=0
while read -r dg; do
  N=$((N+1)); hex=${dg#sha256:}; out=$D/blobs/sha256/$hex
  if [ -s "$out" ] && [ "sha256:$(sha256sum "$out"|cut -d' ' -f1)" = "$dg" ]; then
    echo "[$N/$TOTAL] SKIP $dg"; continue
  fi
  ok=0
  for try in 1 2 3 4 5; do
    T=$(get_token)   # ghcr token ~5min 过期，每个 blob 前重取
    curl -sL --speed-limit 50000 --speed-time 30 -H "Authorization: Bearer $T" \
      -o "$out" "https://$BEST/v2/$REPO/blobs/$dg"
    [ -s "$out" ] && [ "sha256:$(sha256sum "$out"|cut -d' ' -f1)" = "$dg" ] && { ok=1; break; }
    sleep 2
  done
  if [ $ok = 1 ]; then echo "[$N/$TOTAL] OK $dg ($(du -h "$out"|cut -f1))"
  else echo "[$N/$TOTAL] FAIL $dg"; exit 1; fi
done < "$D/digests.txt"

# 4) 组装 OCI 布局。podman 的 oci: transport 拒收 docker MIME 类型，
#    必须把 manifest 转成 OCI 等价类型并重算 manifest 摘要、重写 index.json。
#    config blob 字节不变 → 导入后的 image ID 与上游一致。
python3 - "$D" "$TAG" <<'PY'
import json, hashlib, sys
D, TAG = sys.argv[1], sys.argv[2]
m = json.load(open(f"{D}/manifest.json"))
m["mediaType"] = "application/vnd.oci.image.manifest.v1+json"
m["config"]["mediaType"] = "application/vnd.oci.image.config.v1+json"
for l in m["layers"]:
    mt = l.get("mediaType", "")
    if mt == "application/vnd.docker.image.rootfs.diff.tar.gzip":
        l["mediaType"] = "application/vnd.oci.image.layer.v1.tar+gzip"
    elif mt == "application/vnd.docker.image.rootfs.foreign.diff.tar.gzip":
        l["mediaType"] = "application/vnd.oci.image.layer.v1.tar+gzip+nondistributable"
data = json.dumps(m, separators=(",", ":")).encode()
h = hashlib.sha256(data).hexdigest()
open(f"{D}/manifest_oci.json", "wb").write(data)
open(f"{D}/blobs/sha256/{h}", "wb").write(data)
open(f"{D}/oci-layout", "w").write('{"imageLayoutVersion":"1.0.0"}')
json.dump({"schemaVersion": 2, "mediaType": "application/vnd.oci.image.index.v1+json",
  "manifests": [{"mediaType": "application/vnd.oci.image.manifest.v1+json",
    "digest": "sha256:" + h, "size": len(data),
    "annotations": {"org.opencontainers.image.ref.name": TAG}}]},
  open(f"{D}/index.json", "w"))
PY
echo OCI_READY

# 5) 导入 podman 并 tag 成 ghcr.io 官方名（hal-ver.sh set 即可跳过 pull 直接切）
ID=$(podman pull "oci:$D:$TAG" | tail -1)
[ -n "$ID" ] || { echo IMPORT_FAIL; exit 1; }
podman tag "$ID" "ghcr.io/$REPO:$TAG" && echo "IMAGE_READY $ID"
echo "清理: rm -rf $D"
