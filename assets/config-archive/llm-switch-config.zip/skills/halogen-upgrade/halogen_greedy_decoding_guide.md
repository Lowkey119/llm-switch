# Halogen 推理引擎 - 贪心解码与配置指南

Halogen 是一个专为 **AMD Strix Halo** 硬件（gfx1151）优化的高性能 LLM 推理引擎，由 `peonist-ai` 团队开发。它是 Strix Halo 平台上目前最快的 LLM 推理引擎，专注于运行 **Qwen3.8-Flash-Next** 模型系列。

## 1. 什么是 Halogen 中的贪心解码？

**定义**：贪心解码是最简单的 LLM token 生成策略。在每一步生成中，直接选择模型输出概率最高的下一个 token，然后继续下一步。

### 关键特性：

| 特性 | 说明 |
|------|------|
| **速度** | 最快的解码模式 - 无搜索开销 |
| **确定性** | 相同的模型和提示词 siempre（总是）产生完全相同的输出序列 |
| **字节级等价** | 在温度 0 时，输出与串行解码完全相同 |
| **无额外内存** | 相比其他模式无额外内存开销 |
| **模型默认** | Halogen 默认为贪心解码以获得最大性能 |

### 何时使用贪心解码：
- ✅ 最大速度是必需的
- ✅ 需要确定性、可重现的输出（代码生成、结构化任务）
- ✅ 代理工作流，一致性很重要
- ✅ 使用温度 0 或省略温度参数时

### 何时考虑其他方案：
- ❌ 需要更有创意/连贯的文本（使用温度 > 0 的采样）
- ❌ 需要探索多个 token 路径（使用 beam search 或 nucleus sampling）
- ❌ 需要从同一提示词获得多样化输出

## 2. 配置方法

### 2.1 环境变量（服务器级默认值）

在 `podman run` 或 Docker 命令中设置这些变量以建立服务器级默认值：

| 变量 | 说明 | 默认/范围 |
|------|------|-----------|
| `HALOGEN_TEMPERATURE` | sampled requests 的默认温度 | 模型卡：1.0（思考模式）/ 0.7（非思考模式） |
| `HALOGEN_TOP_P` | nucleus sampling 参数 | 0.95 |
| `HALOGEN_TOP_K` | top-k filtering 参数 | 20 |
| `HALOGEN_REPETITION_PENALTY` | **关键**：贪心解码必须为 `1`，否则返回 400 错误 | 1 |
| `HALOGEN_MAX_TOKENS_DEFAULT` | requests 的默认 max tokens | 16384（agentic turns 推荐） |
| `HALOGEN_REASONING_EFFORT` | 默认 reasoning effort 级别 | `xhigh`（agentic work 推荐） |
| `HALOGEN_ENABLE_THINKING` | 默认是否启用 thinking | `1`（开启）或 `0`（关闭） |
| `HALOGEN_MAX_THINKING_TOKENS` | thinking block 的最大 tokens | 未设置则无上限 |
| `HALOGEN_THINKING_ANSWER_ROOM` | 在 thinking block 中保留 answer room | Auto: `max(1024, 15% of max_tokens)` |
| `HALOGEN_THINKING_BUDGET_MESSAGE` | thinking block 的自定义 closing 句 | Qwen's sentence by default |
| `HALOGEN_VISION_TOWER` | 启用 vision/tower 支持 | `0`（关闭）或 `1`（自动检测） |
| `HALOGEN_VISION_MAX_PIXELS` | image processing 的最大 pixels | 2560x1440（默认） |
| `HALOGEN_TEMPLATE_UNCHECKED` | 跳过 template 一致性检查 | `0`（检查）或 `1`（跳过并警告） |
| `HALOGEN_CHECKPOINT` | 加载的 model checkpoint | Auto-detects latest |
| `HALOGEN_DOWNLOAD` | 从 HuggingFace 下载 | `peonist-ai/halogen-qwen3.8-flash-next` |
| `HALOGEN_API_KEY` | API key 用于授权 | 可选 |

### 2.2 请求级参数（覆盖服务器默认值）

这些可以随每个 API 请求发送以覆盖服务器默认值：

**采样参数**（在 Chat Completions `/v1/chat/completions` 中）：
- `temperature` - `0` = 贪心解码，`>0` = 采样
- `top_p` - nucleus sampling 参数
- `top_k` - top-k filtering 参数
- `min_p` - minimal p sampling 参数
- `presence_penalty` - 存在惩罚（计数 reasoning）
- `frequency_penalty` - 频率惩罚（计数 reasoning）
- `repetition_penalty` - **贪心解码必须为 1**
- `logit_bias` - specific tokens 的 logit 偏置
- `logprobs` - 返回 log 概率
- `top_logprobs` - 返回 1-20 个 top logprobs

**token budget 参数**：
- `max_tokens` / `max_completion_tokens` / `max_output_tokens` - 输出 budget
- `max_thinking_tokens` - thinking block budget
- `reasoning_effort` - `minimal`/`low`/`medium`/`high`/`xhigh`/`max`

**thinking control**：
- `enable_thinking` - request 的 thinking on/off
- `thinking_budget_tokens` - 自定义 thinking budget
- `thinking_answer_room` - thinking budget 内的 answer room

**structured output**：
- `response_format` - `{"type": "json_schema", ...}` 或 `{"type": "json_object"}`
- `HALOGEN_SCHEMA_ESCAPE` - `bind`（从第一个 token）或 `off`

**cache and session**：
- `return_progress` - stream prompt progress chunks
- `X-Halogen-Keep` / `X-Halogen-From` - session fork/join headers

## 3. 贪心解码最佳实践

### 3.1 温度配置

```bash
# 贪心解码（温度 0 或省略默认值）
curl -s localhost:8731/v1/chat/completions -d '{
  "model": "halogen-qwen3.8-flash-next",
  "messages": [{"role": "user", "content": "Hello"}]
}'

# 显式设置 temperature: 0
curl -s localhost:8731/v1/chat/completions -d '{
  "model": "halogen-qwen3.8-flash-next",
  "messages": [{"role": "user", "content": "Hello"}],
  "temperature": 0
}'

# 采样模式（温度 > 0）
curl -s localhost:8731/v1/chat/completions -d '{
  "model": "halogen-qwen3.8-flash-next",
  "messages": [{"role": "user", "content": "Hello"}],
  "temperature": 1.0,
  "top_p": 0.95,
  "top_k": 20
}'
```

### 3.2 通过环境变量设置服务器默认值

```bash
# 使用模型卡推荐的采样默认值启动服务器
podman run --rm -p 8731:8731 \
  -e HALOGEN_TEMPERATURE=1.0 \
  -e HALOGEN_TOP_P=0.95 \
  -e HALOGEN_TOP_K=20 \
  ghcr.io/peonist-ai/halogen-flash-server:0.18.1

# 使用贪心默认值（温度 0）启动服务器
podman run --rm -p 8731:8731 \
  -e HALOGEN_TEMPERATURE=0 \
  ghcr.io/peonist-ai/halogen-flash-server:0.18.1
```

### 3.3 存在惩罚注意事项

> **关键**：发送 `repetition_penalty` 不为 `1` 的贪心请求会返回 400 错误，因为这里的贪心解码与串行解码是字节级别等价的，惩罚会改变结果。

```bash
# 贪心解码配合 repetition_penalty=1（被接受）
curl -s localhost:8731/v1/chat/completions -d '{
  "model": "halogen-qwen3.8-flash-next",
  "messages": [{"role": "user", "content": "Hello"}],
  "temperature": 0,
  "repetition_penalty": 1
}'

# 贪心解码配合 repetition_penalty!=1（400 错误！）
curl -s localhost:8731/v1/chat/completions -d '{
  "model": "halogen-qwen3.8-flash-next",
  "messages": [{"role": "user", "content": "Hello"}],
  "temperature": 0,
  "repetition_penalty": 1.2
}'
```

## 4. 完整使用示例

### 4.1 最大速度配置（贪心解码）

```bash
# 使用 podman 与贪心默认值启动
podman run --rm -p 8731:8731 \
  --device /dev/kfd --device /dev/dri --group-add keep-groups \
  --ipc=host --ulimit memlock=-1:-1 \
  -e HALOGEN_TEMPERATURE=0 \
  -e HALOGEN_REPETITION_PENALTY=1 \
  -e HALOGEN_MAX_TOKENS_DEFAULT=16384 \
  -v ~/halogen-models:/models \
  ghcr.io/peonist-ai/halogen-flash-server:0.18.1
```

### 4.2 采样配置（模型作者推荐）

```bash
# 使用 podman 与采样默认值启动（模型卡推荐此模式）
podman run --rm -p 8731:8731 \
  --device /dev/kfd --device /dev/dri --group-add keep-groups \
  --ipc=host --ulimit memlock=-1:-1 \
  -e HALOGEN_TEMPERATURE=1.0 \
  -e HALOGEN_TOP_P=0.95 \
  -e HALOGEN_TOP_K=20 \
  -e HALOGEN_MAX_TOKENS_DEFAULT=16384 \
  -v ~/halogen-models:/models \
  ghcr.io/peonist-ai/halogen-flash-server:0.18.1
```

### 4.3 API 请求示例

**贪心解码请求**：
```http
POST /v1/chat/completions
Content-Type: application/json

{
  "model": "halogen-qwen3.8-flash-next",
  "messages": [{"role": "user", "content": "Write a Python function to sort a list."}],
  "temperature": 0,
  "max_tokens": 1024
}
```

**采样请求（温度 > 0）**：
```http
POST /v1/chat/completions
Content-Type: application/json

{
  "model": "halogen-qwen3.8-flash-next",
  "messages": [{"role": "user", "content": "Write a Python function to sort a list."}],
  "temperature": 1.0,
  "top_p": 0.95,
  "top_k": 20,
  "max_tokens": 1024
}
```

**包含 thinking 的请求**：
```http
POST /v1/chat/completions
Content-Type: application/json

{
  "model": "halogen-qwen3.8-flash-next",
  "messages": [{"role": "user", "content": "Let me think about this step by step..."}],
  "temperature": 1.0,
  "max_completion_tokens": 16384,
  "reasoning_effort": "high"
}
```

**结构化输出请求**：
```http
POST /v1/chat/completions
Content-Type: application/json

{
  "model": "halogen-qwen3.8-flash-next",
  "messages": [{"role": "user", "content": "Extract the key-value pairs from this text."}],
  "temperature": 0,
  "max_tokens": 512,
  "response_format": {
    "type": "json_schema",
    "json_schema": {
      "name": "ExtractedData",
      "schema": {
        "type": "object",
        "properties": {
          "name": {"type": "string"},
          "value": {"type": "string"}
        },
        "required": ["name", "value"]
      }
    }
  }
}
```

## 5. 文档中的关键配置参考

### Token Budget 管理

| 参数 | 说明 | 默认值 |
|------|------|---------|
| `max_tokens` / `max_completion_tokens` / `max_output_tokens` | 输出 budget（三个别名均可用） | 65536 上限，服务器默认 16384 |
| `HALOGEN_MAX_TOKENS_DEFAULT` | 为所有 route 移动默认值 | 推荐 16384 |
| `HALOGEN_MAX_TOKENS_CAP` | 硬上限（默认 65536） | 超出上限 → 400 错误 |

### Thinking Block 管理

| 参数 | 说明 | 行为 |
|------|------|------|
| `max_thinking_tokens` / `HALOGEN_MAX_THINKING_TOKENS` | 限制 thinking block | N 个 token 后模型关闭 |
| `HALOGEN_THINKING_ANSWER_ROOM` | 保留 answer room | 自动：`max(1024, 15% of max_tokens)` |
| `HALOGEN_THINKING_BUDGET_MESSAGE` | 自定义 closing text | 替代 Qwen's sentence |
| `"reasoning_effort": "none"` | request 级别关闭 thinking | 同 `enable_thinking: false` |

### Cache 配置

| 参数 | 说明 |
|------|------|
| `HALOGEN_CACHE_DIR` | 跨重启持久化 cache |
| `HALOGEN_FORK` | 启用 session fork/join |
| `HALOGEN_FORK_MAP` | Claude Code thread mapping |
| `HALOGEN_FORK_TTL_S` | Handle TTL（秒） |

### Vision 配置

| 参数 | 说明 |
|------|------|
| `HALOGEN_VISION_TOWER` | 启用 vision（0 或 1） |
| `HALOGEN_VISION_MAX_PIXELS` | 默认 2560x1440 |

### Prometheus Metrics

服务器暴露 `/metrics`，包含以下指标：
- `halogen:requests_total`
- `halogen:prompt_tokens_cached_total`
- `halogen:draft_tokens_total`
- `halogen:kv_pool_positions`
- `halogen:kv_pool_reserved_tokens`
- `halogen:cache_hits_total`
- `halogen:cache_misses_total`

## 6. 常见问题排查

### 6.1 服务器无法启动 - 内存不足

**原因**：BIOS 中的 UMA frame buffer 设置过高（例如 Auto = 64 GiB 隐藏了机器一半，导致权重无法加载）

**解决方法**：将 BIOS 中的 UMA frame buffer 设置为最小明确值，而非 Auto。

### 6.2 服务器启动缓慢 - 长提示词

**原因**：不足够的 memlock 或设备访问权限

**解决方法**：确保 `--ulimit memlock=-1:-1` 并正确访问设备(`/dev/kfd`, `/dev/dri`)

### 6.3 贪心解码配合温度返回意外结果

**原因**：`temperature: 0` 必须显式设置或服务器默认必须为 0

**解决方法**：在请求中设置 `temperature: 0` 或设置 `HALOGEN_TEMPERATURE=0` 环境变量

### 6.4 贪心请求中的 `repetition_penalty` 400 错误

**原因**：贪心解码下发送 `repetition_penalty` != 1

**解决方法**：使用 `repetition_penalty: 1` 或完全省略它（贪心解码下）

### 6.5 空回答意味着 budget 耗尽

**原因**：thinking 消耗了整个 token budget

**解决方法**：
- 设置 `HALOGEN_THINKING_ANSWER_ROOM=0` 恢复旧行为
- 使用 `"reasoning_effort": "low"` 减少 thinking
- 增加 `max_tokens` budget
- 设置 `HALOGEN_MAX_TOKENS_DEFAULT=16384` 用于 agentic turns

### 6.6 thinking block 未正确关闭

**原因**：在高 context 下 model 在 thinking block 内循环

**解决方法**：
- 设置 `HALOGEN_MAX_THINKING_TOKENS` 为有界值
- 使用 `"reasoning_effort": "low"` 或 `"none"`
- 设置 `HALOGEN_THINKING_BUDGET_MESSAGE` 以自定义 closing

## 7. 快速参考速查表

### 贪心解码（最大速度）

```bash
# 服务器启动
podman run ... -e HALOGEN_TEMPERATURE=0 -e HALOGEN_REPETITION_PENALTY=1

# API 请求
curl -s localhost:8731/v1/chat/completions -d '{
  "model": "halogen-qwen3.8-flash-next",
  "messages": [{"role": "user", "content": "..."}],
  "temperature": 0,
  "max_tokens": 1024
}'
```

### 采样（推荐）

```bash
# 服务器启动  
podman run ... -e HALOGEN_TEMPERATURE=1.0 -e HALOGEN_TOP_P=0.95 -e HALOGEN_TOP_K=20

# API 请求
curl -s localhost:8731/v1/chat/completions -d '{
  "model": "halogen-qwen3.8-flash-next",
  "messages": [{"role": "user", "content": "..."}],
  "temperature": 1.0,
  "top_p": 0.95,
  "top_k": 20,
  "max_tokens": 1024
}'
```

### 开启 thinking 配合 answer room

```bash
# 服务器启动
podman run ... -e HALOGEN_ENABLE_THINKING=1

# 带 thinking budget 的 API 请求
curl -s localhost:8731/v1/chat/completions -d '{
  "model": "halogen-qwen3.8-flash-next",
  "messages": [{"role": "user", "content": "..."}],
  "max_completion_tokens": 16384,
  "reasoning_effort": "high"
}'
```

### 结构化 JSON 输出

```bash
# 带 schema 的 API 请求
curl -s localhost:8731/v1/chat/completions -d '{
  "model": "halogen-qwen3.8-flash-next",
  "messages": [{"role": "user", "content": "..."}],
  "temperature": 0,
  "max_tokens": 512,
  "response_format": {
    "type": "json_schema",
    "json_schema": {
      "name": "MySchema",
      "schema": {"type": "object", "properties": {...}}
    }
  }
}'
```

---

**最后更新**：基于 Halogen Flash Server v0.18.0 文档  
**硬件**：AMD Strix Halo（Ryzen AI Max+ 395 与 128 GB）  
**模型**：Qwen3.8-Flash-Next（179.55B 参数，4.16 bpw 精度）