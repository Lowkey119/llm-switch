# 代码审查流水线 (mycode_review)

## 定位

当发起方代理完成一个切片并提交后，**可选地**启动此流水线，与用户选定的协商代理进行多轮代码讨论——双方通过文件往返交换意见、批注、反驳，直到达成共识后再由发起方按协商意见实际修改代码并继续 mygoal 循环。协商代理由用户在执行 `mygoal` 时选定（任意已注册到 LLM-Switch 的代理），不限定具体身份。

**触发信号**：`"走一遍 mycode_review"` / `"对刚才那个切片做个 review"` / `"跑一次代码审查"` / `"找个代理帮我审一下"`

**依赖技能**：本技能在运行时从 LLM-Switch 获取 `~/.llm-switch/skills/mygoal/SKILL.md`（即 `~/.pi` 引用的 `mygoal`）作为上下文参考。

---

## 两层目录结构

本技能的核心设计是**两层分治**：

| 层级 | 存放位置 | 谁维护 | 说明 |
|------|----------|--------|------|
| **技能定义（真身）** | `~/.llm-switch/skills/mycode_review/SKILL.md` | LLM-Switch | 一份权威副本，统一分发到需要的代理 |
| **协商交互文件** | 编码仓库专有目录 | 发起方 + 协商方 | 运行时产生的通信数据，git 排除 |

### 1. 技能定义 — 存于 LLM-Switch 管理域

本技能的真身就是 `~/.llm-switch/skills/mycode_review/SKILL.md` 本身。LLM-Switch 负责：

- **存储与维护**：技能的定义只有一份权威副本，存储在 `~/.llm-switch/skills/` 下
- **按需分发**：当某个代理需要使用此技能时，LLM-Switch 将其 SKILL.md 的内容下发给该代理
- **版本同步**：技能的更新由 LLM-Switch 统一推送，所有使用该技能的代理自动获得最新版本

### 2. 协商交互文件 — 落盘仓库专有目录

协商过程中产生的所有 JSON 文件落在实际编码仓库的 `reviews/` 目录下。**此目录加入 `.gitignore`，不入库**。

```
<repo>/
├── .gitignore          # 包含 "/reviews/"
├── reviews/            # ← 仓库专有工作目录，git 排除
│   ├── pending/        # 待处理的审查请求
│   ├── rounds/         # 每轮协商的完整交流记录
│   │   ├── round-01/   # 第 1 轮
│   │   ├── round-02/   # 第 2 轮
│   │   └── ...
│   └── archive/        # 已归档的历史记录
└── <其他代码...>
```

**关键约束**：
- 每个文件的 **写入者是唯一作者**，另一方只做读取者
- 文件名在同一轮次内不变，新轮次用新的子目录
- 处理完毕后该轮目录整体移入 `archive/` 或清空

---

## 架构概览

```
┌─────────── 发起方 ────────────────┐
│                                    │
│  1. 完成切片 → git commit          │
│  2. 写 review-request.json         │
│  3. 等待审查报告                   │
│  4. 写入 counter-comment           │
│  5. 重复 3-4 直到 max_rounds       │
│  6. 按协商意见修改代码             │
│  7. 过门禁 → 提交 + 版本 +0.01     │
│  8. 回写 handoff                    │
└────────────────────────────────────┘
         ▲ 文件 IPC  │  shell 调用
         │           ▼
┌────────────────────────────────────┐
│  审查代理 (任意已注册代理:        │
│   由 LLM-Switch 动态提供)         │
│                                    │
│  读 request.json                   │
│  → 分析并提出问题/建议             │
│  → 写 review-report.json           │
│  收到 counter-comment.json         │
│  → 回复/反驳                      │
│  → 写 updated-report.json          │
└────────────────────────────────────┘
```

---

## 三、完整流程（八步循环）

### 步骤 1：发起方完成切片

正常编码完成后，先打本地提交（含有意义的 commit message）。

```bash
cd <repo>
git add -A && git commit -m "feat: <功能描述>"
```

### 步骤 2：生成审查请求

在 `reviews/pending/` 下写一份 `review-request.json`，文件名格式 `<计划名>-<日期>.json`：

```json
{
  "id": "<plan-name>-2025-01-15",
  "created_at": "2025-01-15T14:30:00Z",
  "author": "发起方代理名称",
  "reviewer": "由用户指定（或留空由系统随机分配）",
  "max_rounds": 5,
  "changes": {
    "files_changed": ["lib/features/foo/bar.dart"],
    "summary": "一句话说明改动目的"
  },
  "context": {
    "what_happened": "详细的技术细节和实现逻辑",
    "why_this_change": "改动的动机和背景",
    "assumptions": ["我假设 X，请确认是否合理"],
    "open_questions": ["Y 是否需要特殊处理？"]
  }
}
```

**关键字段**：
- `max_rounds`：最大协商轮数（默认 5），防止无限循环
- `assumptions`：发起方的预设判断，邀请对方验证或反驳
- `open_questions`：发起方不确定、希望对方帮忙思考的问题

### 步骤 3：启动审查代理

这是最关键的一步——**审查代理由用户在调用 mygoal 时指定，技能本身不预设任何代理**。

代理池由 LLM-Switch 动态管理，技能通过查询 LLM-Switch 获取当前可用的代理列表，而不是硬编码：

```bash
# 从 LLM-Switch 查询当前可用的审查代理（动态，不写死）
llm-switch agents list --role reviewer
# 输出示例（实际内容由 LLM-Switch 决定，为当前已注册的全部可用代理）

# 用用户指定的代理启动审查
./tool/review-agents start \
  --agent <用户指定的代号> \
  --request reviews/pending/<file>.json \
  --output reviews/rounds/round-01/
```

**要点**：
- 技能**不维护**任何代理名单——代理代号、可执行路径、调用方式全部由 LLM-Switch 注册表提供
- 新增一个代理（如某个新 CLI）只需在 LLM-Switch 注册，本技能无需改动
- 发起方与审查方可以是**任意两个不同的代理**（只要双方都遵循同一套 JSON 文件协议）

### 步骤 4：接收审查报告

轮询 `reviews/rounds/round-NN/` 目录，检查是否有 `review-report.json` 生成：

```bash
# 轮询直到报告出现或超时
while [ ! -f "reviews/rounds/round-01/review-report.json" ]; do
  sleep 2
  if [ $(($(date +%s) - start_time)) -gt 300 ]; then
    echo "Review timed out" >&2
    exit 1
  fi
done
```

### 步骤 5：解析审查报告

审查报告格式：

```json
{
  "id": "<same-as-request>",
  "round": 1,
  "reviewed_at": "2025-01-15T14:45:00Z",
  "findings": [
    {
      "category": "bug" | "design" | "style" | "performance" | "missing-test" | "question",
      "severity": "error" | "warning" | "info",
      "line": 42,
      "message": "具体问题描述",
      "reasoning": "为什么这么认为（推理过程）",
      "suggestion": "建议方案（可为空）"
    }
  ],
  "questions_for_author": [
    "关于 Y 的设计决策，你考虑过 Z 情况吗？"
  ],
  "agreement_areas": ["这部分我认为没问题"],
  "disagreement_areas": ["这部分我认为有问题，理由是..."],
  "summary": "整体结论，1-3句话"
}
```

**判定规则**：
- 如果 `!has_disagreements()` 且 `!has_open_questions()` → 直接进入步骤 7（协商一致）
- 如果有 `questions_for_author` 或 `disagreement_areas` → 进入步骤 6（发起方回复）
- 如果累计 `round >= max_rounds` 仍有未解决项 → 进入步骤 7.5（强制裁决）

### 步骤 6：发起方回话（counter-comment）

发起方根据审查报告写入 `reviews/rounds/round-NN/counter-comment.json`：

```json
{
  "id": "<same-as-request>",
  "round": 1,
  "written_at": "2025-01-15T15:00:00Z",
  "responses_to_findings": [
    {
      "target_finding_id": 3,
      "response": "同意你的观点，我会修改为...",
      "action_taken": true
    },
    {
      "target_finding_id": 7,
      "response": "我保留原方案，因为...",
      "reasoning": "详细理由（引用上下文）"
    }
  ],
  "answers_to_questions": [
    {
      "original_question": "Y 是否需要特殊处理？",
      "answer": "是的，我在第 XX 行加了处理"
    }
  ],
  "new_issues_raised": [
    {
      "message": "另外我发现一个问题..."
    }
  ],
  "summary": "本轮审查总结"
}
```

**关键规则**：
- 发起方**可以拒绝**审查者的建议，但必须写出理由
- 发起方**可以提出新问题**（"我又想到一个点..."）
- 不允许沉默跳过任何 finding

### 步骤 7：下一轮协商

将 `counter-comment.json` 交给审查代理，进入下一轮（步骤 4→7）。

每次新轮次，审查代理会看到完整的历次交流历史（`round-01/`, `round-02/` 全部文件），因此可以：
- 回顾之前的分歧点
- 评估发起方的反驳是否站得住脚
- 调整自己的立场

### 步骤 7.5：强制裁决

当 `round >= max_rounds` 仍有未解决项时：

```bash
./tool/review-agents force-decide \
  --input reviews/rounds/ \
  --final reviews/final.json
```

输出最终裁决报告，不再允许回话。

### 步骤 8：发起方按协商意见执行修改

收到最终的 `review-report.json` 或 `final.json` 后，**发起方必须根据报告中的 findings 逐一修改代码**。这一步不是走形式——是真正的编码工作。

具体操作：
1. **逐条处理 finding**：对每个 `severity == "error"` 的 finding 进行修改；`"warning"` 级别的由发起方判断是否值得修（如果协商过程中双方已就某个 warning 达成共识，则必须修）。
2. **补充测试**：如果发现原来缺少回归测试，补上对应的测试用例。
3. **过门禁**：重新跑烟测（`flutter analyze` + `flutter test`），确保修改没有引入回归。
4. **打提交**：以有意义的 commit message 提交修改。
5. **版本号 +0.01**：按照铁律 10 打 tag 并推送远程。
6. **回写 handoff**：更新 `handoff.md` 当前 HEAD 部分，记录本次审查的结果和遗留关注。

---

## 四、审查代理的 prompt 模板

### 第一轮（初始审查）

当 `review-agents start` 被调用时，它会向目标代理注入以下 prompt：

```markdown
你是 <reviewer_name>，正在进行一次切片代码审查。

【任务】
审阅发起方提交的代码变更，以开放态度提出问题、建议或疑问。
不要急于下结论——你的目标是发现潜在问题，而不是证明自己是正确的。

【审查维度】
1. 逻辑正确性：边界 case 遗漏？竞态条件？内存泄漏？
2. 架构合理性：是否符合项目既有模式？有没有更好的组织方式？
3. 可维护性：未来三个月维护者能否理解这段代码？
4. 测试覆盖：现有测试是否足够？缺少哪些场景？
5. 用户体验：如果有 UI 部分，交互是否直观？

【发起方的预设】
<来自 review-request.json 的 context>
特别是其中的 assumptions 和 open_questions，请重点回应。

【输出要求】
请将审查报告写入指定输出路径（JSON 格式，字段见下方 schema）。
不要输出其他内容。
```

### 后续轮次（收到 counter-comment 后）

```markdown
你是 <reviewer_name>，正在进行切片代码审查的第 <round> 轮。

【历史交流】
以下是之前轮次的完整交流记录（请在 reviews/rounds/round-* 中查看）：
- 第 N 轮：你的原始报告
- 第 N+1 轮：发起方的反驳/补充

【当前任务】
1. 评估发起方的反驳是否站得住脚
2. 如果对方的理由充分，承认自己之前的判断可能需要调整
3. 如果对方确实忽略了某些问题，坚持立场但要更精确地表述
4. 注意发起方可能提出的新问题

【约束】
- 不要重复已经解决的问题
- 不要攻击发起方的人格，只讨论技术
- 如果你的立场发生摇摆，明确标注"我之前认为 X，现在改为 Y，因为 Z"

【输出要求】
请将更新后的审查报告写入指定输出路径（JSON 格式，字段见下方 schema）。
```

---

## 五、错误处理

| 场景 | 处理方式 |
|------|----------|
| 审查代理未安装 | 提示用户安装或换另一个 |
| 单轮超时 | 标记该轮 `timeout`，发起方决定是否继续 |
| 报告格式错误 | 尝试修复，失败则跳过该片 |
| 达到 max_rounds 仍有分歧 | 进入 force-decide 阶段 |
| 连续 3 轮无实质进展 | 熔断，记入跳过台账 |
| 审查发现阻塞性问题 | 标记 `blocked`，整片丢弃 |

---

## 六、init 命令的实现要点

```bash
#!/bin/bash
# tool/mycode-review-init.sh

REPO_ROOT="$1"
[ -z "$REPO_ROOT" ] && REPO_ROOT=$(git rev-parse --show-toplevel)

mkdir -p "$REPO_ROOT/reviews/pending"
mkdir -p "$REPO_ROOT/reviews/rounds"
mkdir -p "$REPO_ROOT/reviews/archive"

# 将 reviews/ 加入 .gitignore（仅本地工作产物）
grep -q '/reviews/' "$REPO_ROOT/.gitignore" || \
  echo "/reviews/" >> "$REPO_ROOT/.gitignore"

echo "✓ Mycode review pipeline initialized at $REPO_ROOT/reviews/"
```

---

## 七、使用示例

### 基础用法

```bash
# 初始化项目
mycode-review init ~/my-project

# 在 mygoal 循环中，切片完成后触发审查
mycode-review run --auto
```

### 手动指定审查者

```bash
# 用某个已注册代理审查（代号来自 LLM-Switch 注册表，任意可用代理）
mycode-review run --reviewer <代号>

# 用两个代理交叉审查（同时开两路）
mycode-review run --reviewers <代号A> <代号B> --mode cross
```

> 代理代号不写死在本技能里——全部由 `llm-switch agents list --role reviewer` 动态提供。

---

## 八、注意事项

1. **审查 ≠ 对抗**：审查的目的是找到更好的方案，不是"赢"。发起方和审查方应该互相尊重、理性讨论。

2. **不要无限循环**：设置合理的 `max_rounds`（建议 3-5 轮），超过后强制执行裁决。

3. **成本意识**：不同审查代理的执行成本不等，应在配置中允许设置预算上限。

4. **隐私考虑**：审查过程中会暂存代码片段，审查完成后应自动清理 `pending/` 中的临时文件。

5. **版本兼容性**：审查报告的 JSON schema 应保持向后兼容——新增字段不应破坏旧版工具的解析。

6. **发起方有权拒绝**：发起方可以不采纳审查者的建议，但必须写明理由。这不同于单向审查——审查是双向的。

7. **不要过度审查**：对于简单的小改动（如拼写修正、变量重命名），不需要走审查流程。审查适合涉及 API 变更、架构调整、核心逻辑重构的场景。
